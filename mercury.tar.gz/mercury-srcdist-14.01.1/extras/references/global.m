:- module global.
:- interface.
:- import_module nb_reference.
:- import_module reference.
:- import_module scoped_update.
:- implementation.
:- pragma require_feature_set([trailing]).
