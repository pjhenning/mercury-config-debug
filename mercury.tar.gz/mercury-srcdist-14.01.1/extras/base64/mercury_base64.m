:- module mercury_base64.
:- interface.

:- import_module base64.
