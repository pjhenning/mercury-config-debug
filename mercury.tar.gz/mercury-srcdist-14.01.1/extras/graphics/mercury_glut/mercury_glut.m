%-----------------------------------------------------------------------------%
% Copyright (C) 2004 The University of Melbourne.
% This file may only be copied under the terms of the GNU Library General
% Public License - see the file COPYING.LIB in the Mercury distribution.
%-----------------------------------------------------------------------------%
% 
% file: mercury_glut.m
% author: juliensf
%
%-----------------------------------------------------------------------------%

:- module mercury_glut.

:- interface.

:- import_module glut.

%-----------------------------------------------------------------------------%
:- end_module mercury_glut.
%-----------------------------------------------------------------------------%

