%-----------------------------------------------------------------------------%
% Copyright (C) 2012 The University of Melbourne.
% This file may only be copied under the terms of the GNU Library General
% Public License - see the file COPYING.LIB in the Mercury distribution.
%-----------------------------------------------------------------------------%
% 
% file: mercury_glfw.m
% author: juliensf
%
%-----------------------------------------------------------------------------%

:- module mercury_glfw.

:- interface.

:- import_module glfw.

%-----------------------------------------------------------------------------%
:- end_module mercury_glfw.
%-----------------------------------------------------------------------------%

