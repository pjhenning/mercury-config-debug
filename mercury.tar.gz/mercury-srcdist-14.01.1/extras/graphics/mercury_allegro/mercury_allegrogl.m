%-----------------------------------------------------------------------------%
% Copyright (C) 2005-2007 Peter Wang.
% Copyright (C) 2007 The University of Melbourne.
%-----------------------------------------------------------------------------%
%
% This file is used to create libmercury_allegrogl.a instead of
% liballegrogl.a.
%

:- module mercury_allegrogl.

:- import_module allegrogl.

%-----------------------------------------------------------------------------%
% vi:ft=mercury:ts=8:sts=4:sw=4:et
