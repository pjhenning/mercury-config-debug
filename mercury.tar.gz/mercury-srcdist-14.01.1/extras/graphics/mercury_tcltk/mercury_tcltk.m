%-----------------------------------------------------------------------------%
% Copyright (C) 1997-1998 The University of Melbourne.
% This file may only be copied under the terms of the GNU Library General
% Public License - see the file COPYING.LIB in the Mercury distribution.
%-----------------------------------------------------------------------------%
%-----------------------------------------------------------------------------%

% mercury_tcltk -- a Mercury binding for Tcl/Tk.

:- module mercury_tcltk.

:- import_module mtk, mtcltk.

