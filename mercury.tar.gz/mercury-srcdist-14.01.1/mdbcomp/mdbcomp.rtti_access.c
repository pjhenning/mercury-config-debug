/*
** Automatically generated from `rtti_access.m'
** by the Mercury compiler,
** version 14.01.1, configured for x86_64-apple-darwin13.3.0.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
** PREGENERATED_DIST=yes
** HIGHLEVEL_CODE=yes
**
** END_OF_C_GRADE_INFO
*/


/* :- module mdbcomp.rtti_access. */
/* :- implementation. */

/*
INIT mercury__mdbcomp__rtti_access__init
ENDINIT
*/

#include "mdbcomp.rtti_access.mih"


#include "array.mih"
#include "assoc_list.mih"
#include "bimap.mih"
#include "bitmap.mih"
#include "bool.mih"
#include "builtin.mih"
#include "char.mih"
#include "construct.mih"
#include "deconstruct.mih"
#include "enum.mih"
#include "int.mih"
#include "io.mih"
#include "list.mih"
#include "map.mih"
#include "maybe.mih"
#include "mdbcomp.mih"
#include "ops.mih"
#include "pair.mih"
#include "pretty_printer.mih"
#include "private_builtin.mih"
#include "random.mih"
#include "require.mih"
#include "rtti_implementation.mih"
#include "set.mih"
#include "set_ordlist.mih"
#include "stream.mih"
#include "string.mih"
#include "term.mih"
#include "time.mih"
#include "tree234.mih"
#include "type_desc.mih"
#include "univ.mih"
#include "mdbcomp.goal_path.mih"
#include "mdbcomp.prim_data.mih"
#include "mdbcomp.trace_counts.mih"




#line 70 "mdbcomp.rtti_access.c"
static const MR_PseudoTypeInfo mdbcomp__rtti_access__mdbcomp__rtti_access__field_types_bytecode_0_0[2];

#line 73 "mdbcomp.rtti_access.c"
static const MR_DuFunctorDesc mdbcomp__rtti_access__mdbcomp__rtti_access__du_functor_desc_bytecode_0_0;

#line 76 "mdbcomp.rtti_access.c"
static const MR_DuFunctorDescPtr mdbcomp__rtti_access__mdbcomp__rtti_access__du_stag_ordered_bytecode_0_0[1];

#line 79 "mdbcomp.rtti_access.c"
static const MR_DuPtagLayout mdbcomp__rtti_access__mdbcomp__rtti_access__du_ptag_ordered_bytecode_0[1];

#line 82 "mdbcomp.rtti_access.c"
static const MR_DuFunctorDescPtr mdbcomp__rtti_access__mdbcomp__rtti_access__du_name_ordered_bytecode_0[1];

#line 85 "mdbcomp.rtti_access.c"
static const MR_Integer mdbcomp__rtti_access__mdbcomp__rtti_access__functor_number_map_bytecode_0[1];

#line 88 "mdbcomp.rtti_access.c"
static const MR_PseudoTypeInfo mdbcomp__rtti_access__mdbcomp__rtti_access__field_types_string_table_0_0[2];

#line 91 "mdbcomp.rtti_access.c"
static const MR_DuFunctorDesc mdbcomp__rtti_access__mdbcomp__rtti_access__du_functor_desc_string_table_0_0;

#line 94 "mdbcomp.rtti_access.c"
static const MR_DuFunctorDescPtr mdbcomp__rtti_access__mdbcomp__rtti_access__du_stag_ordered_string_table_0_0[1];

#line 97 "mdbcomp.rtti_access.c"
static const MR_DuPtagLayout mdbcomp__rtti_access__mdbcomp__rtti_access__du_ptag_ordered_string_table_0[1];

#line 100 "mdbcomp.rtti_access.c"
static const MR_DuFunctorDescPtr mdbcomp__rtti_access__mdbcomp__rtti_access__du_name_ordered_string_table_0[1];

#line 103 "mdbcomp.rtti_access.c"
static const MR_Integer mdbcomp__rtti_access__mdbcomp__rtti_access__functor_number_map_string_table_0[1];

#line 106 "mdbcomp.rtti_access.c"
static MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____bytecode_0_0_10001(
#line 109 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1,
#line 111 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2);

#line 114 "mdbcomp.rtti_access.c"
static void MR_CALL 
mdbcomp__rtti_access____Compare____bytecode_0_0_10001(
#line 117 "mdbcomp.rtti_access.c"
  MR_Box * mdbcomp__rtti_access__wrapper_arg_1,
#line 119 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2,
#line 121 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_3);

#line 124 "mdbcomp.rtti_access.c"
static MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____bytecode_bytes_0_0_10001(
#line 127 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1,
#line 129 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2);

#line 132 "mdbcomp.rtti_access.c"
static void MR_CALL 
mdbcomp__rtti_access____Compare____bytecode_bytes_0_0_10001(
#line 135 "mdbcomp.rtti_access.c"
  MR_Box * mdbcomp__rtti_access__wrapper_arg_1,
#line 137 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2,
#line 139 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_3);

#line 142 "mdbcomp.rtti_access.c"
static MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____label_layout_0_0_10001(
#line 145 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1,
#line 147 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2);

#line 150 "mdbcomp.rtti_access.c"
static void MR_CALL 
mdbcomp__rtti_access____Compare____label_layout_0_0_10001(
#line 153 "mdbcomp.rtti_access.c"
  MR_Box * mdbcomp__rtti_access__wrapper_arg_1,
#line 155 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2,
#line 157 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_3);

#line 160 "mdbcomp.rtti_access.c"
static MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____module_layout_0_0_10001(
#line 163 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1,
#line 165 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2);

#line 168 "mdbcomp.rtti_access.c"
static void MR_CALL 
mdbcomp__rtti_access____Compare____module_layout_0_0_10001(
#line 171 "mdbcomp.rtti_access.c"
  MR_Box * mdbcomp__rtti_access__wrapper_arg_1,
#line 173 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2,
#line 175 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_3);

#line 178 "mdbcomp.rtti_access.c"
static MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____proc_layout_0_0_10001(
#line 181 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1,
#line 183 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2);

#line 186 "mdbcomp.rtti_access.c"
static void MR_CALL 
mdbcomp__rtti_access____Compare____proc_layout_0_0_10001(
#line 189 "mdbcomp.rtti_access.c"
  MR_Box * mdbcomp__rtti_access__wrapper_arg_1,
#line 191 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2,
#line 193 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_3);

#line 196 "mdbcomp.rtti_access.c"
static MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____string_table_0_0_10001(
#line 199 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1,
#line 201 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2);

#line 204 "mdbcomp.rtti_access.c"
static void MR_CALL 
mdbcomp__rtti_access____Compare____string_table_0_0_10001(
#line 207 "mdbcomp.rtti_access.c"
  MR_Box * mdbcomp__rtti_access__wrapper_arg_1,
#line 209 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2,
#line 211 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_3);

#line 214 "mdbcomp.rtti_access.c"
static MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____string_table_chars_0_0_10001(
#line 217 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1,
#line 219 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2);

#line 222 "mdbcomp.rtti_access.c"
static void MR_CALL 
mdbcomp__rtti_access____Compare____string_table_chars_0_0_10001(
#line 225 "mdbcomp.rtti_access.c"
  MR_Box * mdbcomp__rtti_access__wrapper_arg_1,
#line 227 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2,
#line 229 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_3);

#line 785 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__f_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_98_121_116_101_99_111_100_101_95_115_116_114_105_110_103_95_116_97_98_108_101_95_50_95_95_91_49_44_32_50_93_95_48_4_p_0(
#line 785 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__1_1,
#line 785 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__2_2,
#line 785 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__3_3,
#line 785 "rtti_access.m"
  MR_Box * mdbcomp__rtti_access__HeadVar__4_4);

#line 864 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__encode_num_2_3_p_0(
#line 864 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Num_4,
#line 864 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__RestBytes_5,
#line 864 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__Bytes_6);

#line 785 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__bytecode_string_table_2_4_p_0(
#line 785 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__TypeInfo_for_Offset_5,
#line 785 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__TypeInfo_for_Size_6,
#line 785 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__1_1,
#line 785 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__2_2,
#line 785 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__3_3,
#line 785 "rtti_access.m"
  MR_Box * mdbcomp__rtti_access__HeadVar__4_4);

#line 764 "rtti_access.m"
static MR_bool MR_CALL 
mdbcomp__rtti_access__read_len_string_2_6_p_0(
#line 764 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__ByteCode_7,
#line 764 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__N_8,
#line 764 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__STATE_VARIABLE_RevChars_0_13,
#line 764 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__STATE_VARIABLE_RevChars_14,
#line 764 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_15,
#line 764 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__STATE_VARIABLE_Pos_16);

#line 746 "rtti_access.m"
static MR_bool MR_CALL 
mdbcomp__rtti_access__read_line_2_5_p_0(
#line 746 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__ByteCode_6,
#line 746 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__STATE_VARIABLE_RevChars_0_11,
#line 746 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__STATE_VARIABLE_RevChars_12,
#line 746 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_13,
#line 746 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__STATE_VARIABLE_Pos_14);

#line 726 "rtti_access.m"
static MR_bool MR_CALL 
mdbcomp__rtti_access__read_num_2_5_p_0(
#line 726 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__ByteCode_6,
#line 726 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Num0_7,
#line 726 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Num_8,
#line 726 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_12,
#line 726 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__STATE_VARIABLE_Pos_13);

#line 712 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__read_int32_2_4_p_0(
#line 712 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__ByteCode_1,
#line 712 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Value_2,
#line 712 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Pos0_3,
#line 712 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Pos_4);

#line 697 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__read_short_2_4_p_0(
#line 697 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__ByteCode_1,
#line 697 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Value_2,
#line 697 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Pos0_3,
#line 697 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Pos_4);

#line 682 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__read_byte_2_4_p_0(
#line 682 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__ByteCode_1,
#line 682 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Value_2,
#line 682 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Pos0_3,
#line 682 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Pos_4);

#line 656 "rtti_access.m"
static MR_String MR_CALL 
mdbcomp__rtti_access__lookup_string_table_2_3_f_0(
#line 656 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__StringTableChars_1,
#line 656 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__StringTableSize_2,
#line 656 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__NameCode_3);

#line 640 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__module_string_table_components_3_p_0(
#line 640 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__ModuleLayout_1,
#line 640 "rtti_access.m"
  MR_Box * mdbcomp__rtti_access__StringTableChars_2,
#line 640 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Size_3);

#line 322 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__proc_layout_get_non_uci_fields_7_p_0(
#line 322 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__Layout_1,
#line 322 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__PredOrFunc_2,
#line 322 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__DeclModule_3,
#line 322 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__DefModule_4,
#line 322 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__PredName_5,
#line 322 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Arity_6,
#line 322 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__ModeNum_7);

#line 301 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__proc_layout_get_uci_fields_7_p_0(
#line 301 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__Layout_1,
#line 301 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__TypeName_2,
#line 301 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__TypeModule_3,
#line 301 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__DefModule_4,
#line 301 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__PredName_5,
#line 301 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__TypeArity_6,
#line 301 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__ModeNum_7);

#line 288 "rtti_access.m"
static MR_bool MR_CALL 
mdbcomp__rtti_access__proc_layout_is_uci_1_p_0(
#line 288 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__Layout_1);

#line 889 "rtti_access.m"
static MR_Box MR_CALL 
mdbcomp__rtti_access__encode_len_string_2_p_0_1(
#line 889 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__closure_arg,
#line 889 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1);


static /* final */ const MR_Box mdbcomp__rtti_access_scalar_common_1[1][5];

static /* final */ const MR_Box mdbcomp__rtti_access_scalar_common_2[1][3];




static /* final */ const MR_Box mdbcomp__rtti_access_scalar_common_1[1][5] = {
  /* row 0 */
  {
    NULL,
    ((MR_Box) (NULL)),
    ((MR_Box) (MR_Word) ((MR_Integer) 2)),
    ((MR_Box) (&mercury__builtin__builtin__type_ctor_info_character_0)),
    ((MR_Box) (&mercury__builtin__builtin__type_ctor_info_int_0))
  },
};

static /* final */ const MR_Box mdbcomp__rtti_access_scalar_common_2[1][3] = {
  /* row 0 */
  {
    ((MR_Box) (&mdbcomp__rtti_access_scalar_common_1[0])),
    ((MR_Box) (mdbcomp__rtti_access__encode_len_string_2_p_0_1)),
    ((MR_Box) (MR_Word) ((MR_Integer) 0))
  },
};



#include "mdbcomp.rtti_access.mh"
#include "mdbcomp.mh"
#include "array.mh"
#include "array.mh"
#include "io.mh"
#include "io.mh"
#include "time.mh"
#include "string.mh"
#include "bitmap.mh"
#include "bitmap.mh"
#include "time.mh"
#include "time.mh"



#line 465 "mdbcomp.rtti_access.c"
static const MR_PseudoTypeInfo mdbcomp__rtti_access__mdbcomp__rtti_access__field_types_bytecode_0_0[2] = {
  (MR_PseudoTypeInfo) &mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_bytecode_bytes_0,
  (MR_PseudoTypeInfo) &mercury__builtin__builtin__type_ctor_info_int_0
};

#line 471 "mdbcomp.rtti_access.c"
static const MR_DuFunctorDesc mdbcomp__rtti_access__mdbcomp__rtti_access__du_functor_desc_bytecode_0_0 = {
  (MR_String) "bytecode",
  (MR_Integer) 2,
  (MR_Integer) 0,
  mercury__private_builtin__MR_SECTAG_NONE,
  (MR_Integer) 0,
  (MR_Integer) -1,
  (MR_Integer) 0,
  mdbcomp__rtti_access__mdbcomp__rtti_access__field_types_bytecode_0_0,
  NULL,
  NULL,
  NULL
};

#line 486 "mdbcomp.rtti_access.c"
static const MR_DuFunctorDescPtr mdbcomp__rtti_access__mdbcomp__rtti_access__du_stag_ordered_bytecode_0_0[1] = {
  &mdbcomp__rtti_access__mdbcomp__rtti_access__du_functor_desc_bytecode_0_0
};

#line 491 "mdbcomp.rtti_access.c"
static const MR_DuPtagLayout mdbcomp__rtti_access__mdbcomp__rtti_access__du_ptag_ordered_bytecode_0[1] = {
  {
    (MR_Integer) 1,
    mercury__private_builtin__MR_SECTAG_NONE,
    mdbcomp__rtti_access__mdbcomp__rtti_access__du_stag_ordered_bytecode_0_0
  }
};

#line 500 "mdbcomp.rtti_access.c"
static const MR_DuFunctorDescPtr mdbcomp__rtti_access__mdbcomp__rtti_access__du_name_ordered_bytecode_0[1] = {
  &mdbcomp__rtti_access__mdbcomp__rtti_access__du_functor_desc_bytecode_0_0
};

#line 505 "mdbcomp.rtti_access.c"
static const MR_Integer mdbcomp__rtti_access__mdbcomp__rtti_access__functor_number_map_bytecode_0[1] = {
  (MR_Integer) 0
};

#line 510 "mdbcomp.rtti_access.c"
const MR_TypeCtorInfo_Struct mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_bytecode_0 = {
  (MR_Integer) 0,
  (MR_Integer) 15,
  (MR_Integer) 1,
  mercury__private_builtin__MR_TYPECTOR_REP_DU,
  ((MR_Box) (mdbcomp__rtti_access____Unify____bytecode_0_0_10001)),
  ((MR_Box) (mdbcomp__rtti_access____Compare____bytecode_0_0_10001)),
  (MR_String) "mdbcomp.rtti_access",
  (MR_String) "bytecode",
  {
    mdbcomp__rtti_access__mdbcomp__rtti_access__du_name_ordered_bytecode_0
  },
  {
    mdbcomp__rtti_access__mdbcomp__rtti_access__du_ptag_ordered_bytecode_0
  },
  (MR_Integer) 1,
  (MR_Integer) 4,
  mdbcomp__rtti_access__mdbcomp__rtti_access__functor_number_map_bytecode_0
};

#line 531 "mdbcomp.rtti_access.c"
const MR_TypeCtorInfo_Struct mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_bytecode_bytes_0 = {
  (MR_Integer) 0,
  (MR_Integer) 15,
  (MR_Integer) -1,
  mercury__private_builtin__MR_TYPECTOR_REP_STABLE_FOREIGN,
  ((MR_Box) (mdbcomp__rtti_access____Unify____bytecode_bytes_0_0_10001)),
  ((MR_Box) (mdbcomp__rtti_access____Compare____bytecode_bytes_0_0_10001)),
  (MR_String) "mdbcomp.rtti_access",
  (MR_String) "bytecode_bytes",
  {
    NULL
  },
  {
    NULL
  },
  (MR_Integer) -1,
  (MR_Integer) 0,
  NULL
};

#line 552 "mdbcomp.rtti_access.c"
const MR_TypeCtorInfo_Struct mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_label_layout_0 = {
  (MR_Integer) 0,
  (MR_Integer) 15,
  (MR_Integer) -1,
  mercury__private_builtin__MR_TYPECTOR_REP_STABLE_FOREIGN,
  ((MR_Box) (mdbcomp__rtti_access____Unify____label_layout_0_0_10001)),
  ((MR_Box) (mdbcomp__rtti_access____Compare____label_layout_0_0_10001)),
  (MR_String) "mdbcomp.rtti_access",
  (MR_String) "label_layout",
  {
    NULL
  },
  {
    NULL
  },
  (MR_Integer) -1,
  (MR_Integer) 0,
  NULL
};

#line 573 "mdbcomp.rtti_access.c"
const MR_TypeCtorInfo_Struct mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_module_layout_0 = {
  (MR_Integer) 0,
  (MR_Integer) 15,
  (MR_Integer) -1,
  mercury__private_builtin__MR_TYPECTOR_REP_STABLE_FOREIGN,
  ((MR_Box) (mdbcomp__rtti_access____Unify____module_layout_0_0_10001)),
  ((MR_Box) (mdbcomp__rtti_access____Compare____module_layout_0_0_10001)),
  (MR_String) "mdbcomp.rtti_access",
  (MR_String) "module_layout",
  {
    NULL
  },
  {
    NULL
  },
  (MR_Integer) -1,
  (MR_Integer) 0,
  NULL
};

#line 594 "mdbcomp.rtti_access.c"
const MR_TypeCtorInfo_Struct mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_proc_layout_0 = {
  (MR_Integer) 0,
  (MR_Integer) 15,
  (MR_Integer) -1,
  mercury__private_builtin__MR_TYPECTOR_REP_STABLE_FOREIGN,
  ((MR_Box) (mdbcomp__rtti_access____Unify____proc_layout_0_0_10001)),
  ((MR_Box) (mdbcomp__rtti_access____Compare____proc_layout_0_0_10001)),
  (MR_String) "mdbcomp.rtti_access",
  (MR_String) "proc_layout",
  {
    NULL
  },
  {
    NULL
  },
  (MR_Integer) -1,
  (MR_Integer) 0,
  NULL
};

#line 615 "mdbcomp.rtti_access.c"
static const MR_PseudoTypeInfo mdbcomp__rtti_access__mdbcomp__rtti_access__field_types_string_table_0_0[2] = {
  (MR_PseudoTypeInfo) &mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_string_table_chars_0,
  (MR_PseudoTypeInfo) &mercury__builtin__builtin__type_ctor_info_int_0
};

#line 621 "mdbcomp.rtti_access.c"
static const MR_DuFunctorDesc mdbcomp__rtti_access__mdbcomp__rtti_access__du_functor_desc_string_table_0_0 = {
  (MR_String) "string_table",
  (MR_Integer) 2,
  (MR_Integer) 0,
  mercury__private_builtin__MR_SECTAG_NONE,
  (MR_Integer) 0,
  (MR_Integer) -1,
  (MR_Integer) 0,
  mdbcomp__rtti_access__mdbcomp__rtti_access__field_types_string_table_0_0,
  NULL,
  NULL,
  NULL
};

#line 636 "mdbcomp.rtti_access.c"
static const MR_DuFunctorDescPtr mdbcomp__rtti_access__mdbcomp__rtti_access__du_stag_ordered_string_table_0_0[1] = {
  &mdbcomp__rtti_access__mdbcomp__rtti_access__du_functor_desc_string_table_0_0
};

#line 641 "mdbcomp.rtti_access.c"
static const MR_DuPtagLayout mdbcomp__rtti_access__mdbcomp__rtti_access__du_ptag_ordered_string_table_0[1] = {
  {
    (MR_Integer) 1,
    mercury__private_builtin__MR_SECTAG_NONE,
    mdbcomp__rtti_access__mdbcomp__rtti_access__du_stag_ordered_string_table_0_0
  }
};

#line 650 "mdbcomp.rtti_access.c"
static const MR_DuFunctorDescPtr mdbcomp__rtti_access__mdbcomp__rtti_access__du_name_ordered_string_table_0[1] = {
  &mdbcomp__rtti_access__mdbcomp__rtti_access__du_functor_desc_string_table_0_0
};

#line 655 "mdbcomp.rtti_access.c"
static const MR_Integer mdbcomp__rtti_access__mdbcomp__rtti_access__functor_number_map_string_table_0[1] = {
  (MR_Integer) 0
};

#line 660 "mdbcomp.rtti_access.c"
const MR_TypeCtorInfo_Struct mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_string_table_0 = {
  (MR_Integer) 0,
  (MR_Integer) 15,
  (MR_Integer) 1,
  mercury__private_builtin__MR_TYPECTOR_REP_DU,
  ((MR_Box) (mdbcomp__rtti_access____Unify____string_table_0_0_10001)),
  ((MR_Box) (mdbcomp__rtti_access____Compare____string_table_0_0_10001)),
  (MR_String) "mdbcomp.rtti_access",
  (MR_String) "string_table",
  {
    mdbcomp__rtti_access__mdbcomp__rtti_access__du_name_ordered_string_table_0
  },
  {
    mdbcomp__rtti_access__mdbcomp__rtti_access__du_ptag_ordered_string_table_0
  },
  (MR_Integer) 1,
  (MR_Integer) 4,
  mdbcomp__rtti_access__mdbcomp__rtti_access__functor_number_map_string_table_0
};

#line 681 "mdbcomp.rtti_access.c"
const MR_TypeCtorInfo_Struct mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_string_table_chars_0 = {
  (MR_Integer) 0,
  (MR_Integer) 15,
  (MR_Integer) -1,
  mercury__private_builtin__MR_TYPECTOR_REP_STABLE_FOREIGN,
  ((MR_Box) (mdbcomp__rtti_access____Unify____string_table_chars_0_0_10001)),
  ((MR_Box) (mdbcomp__rtti_access____Compare____string_table_chars_0_0_10001)),
  (MR_String) "mdbcomp.rtti_access",
  (MR_String) "string_table_chars",
  {
    NULL
  },
  {
    NULL
  },
  (MR_Integer) -1,
  (MR_Integer) 0,
  NULL
};

#line 702 "mdbcomp.rtti_access.c"
static MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____bytecode_0_0_10001(
#line 705 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1,
#line 707 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2)
#line 709 "mdbcomp.rtti_access.c"
{
#line 711 "mdbcomp.rtti_access.c"
  {
#line 713 "mdbcomp.rtti_access.c"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 716 "mdbcomp.rtti_access.c"
    {
#line 718 "mdbcomp.rtti_access.c"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access____Unify____bytecode_0_0(((MR_Word) mdbcomp__rtti_access__wrapper_arg_1), ((MR_Word) mdbcomp__rtti_access__wrapper_arg_2));
    }
#line 721 "mdbcomp.rtti_access.c"
    return mdbcomp__rtti_access__succeeded;
#line 723 "mdbcomp.rtti_access.c"
  }
#line 725 "mdbcomp.rtti_access.c"
}

#line 728 "mdbcomp.rtti_access.c"
static void MR_CALL 
mdbcomp__rtti_access____Compare____bytecode_0_0_10001(
#line 731 "mdbcomp.rtti_access.c"
  MR_Box * mdbcomp__rtti_access__wrapper_arg_1,
#line 733 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2,
#line 735 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_3)
#line 737 "mdbcomp.rtti_access.c"
{
#line 739 "mdbcomp.rtti_access.c"
  {
#line 741 "mdbcomp.rtti_access.c"
    MR_Word mdbcomp__rtti_access__conv0_HeadVar__1_1;

#line 744 "mdbcomp.rtti_access.c"
    {
#line 746 "mdbcomp.rtti_access.c"
      mdbcomp__rtti_access____Compare____bytecode_0_0(&mdbcomp__rtti_access__conv0_HeadVar__1_1, ((MR_Word) mdbcomp__rtti_access__wrapper_arg_2), ((MR_Word) mdbcomp__rtti_access__wrapper_arg_3));
    }
#line 749 "mdbcomp.rtti_access.c"
    *mdbcomp__rtti_access__wrapper_arg_1 = ((MR_Box) (mdbcomp__rtti_access__conv0_HeadVar__1_1));
#line 751 "mdbcomp.rtti_access.c"
  }
#line 753 "mdbcomp.rtti_access.c"
}

#line 756 "mdbcomp.rtti_access.c"
static MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____bytecode_bytes_0_0_10001(
#line 759 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1,
#line 761 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2)
#line 763 "mdbcomp.rtti_access.c"
{
#line 765 "mdbcomp.rtti_access.c"
  {
#line 767 "mdbcomp.rtti_access.c"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 770 "mdbcomp.rtti_access.c"
    {
#line 772 "mdbcomp.rtti_access.c"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access____Unify____bytecode_bytes_0_0(((MR_Box) mdbcomp__rtti_access__wrapper_arg_1), ((MR_Box) mdbcomp__rtti_access__wrapper_arg_2));
    }
#line 775 "mdbcomp.rtti_access.c"
    return mdbcomp__rtti_access__succeeded;
#line 777 "mdbcomp.rtti_access.c"
  }
#line 779 "mdbcomp.rtti_access.c"
}

#line 782 "mdbcomp.rtti_access.c"
static void MR_CALL 
mdbcomp__rtti_access____Compare____bytecode_bytes_0_0_10001(
#line 785 "mdbcomp.rtti_access.c"
  MR_Box * mdbcomp__rtti_access__wrapper_arg_1,
#line 787 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2,
#line 789 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_3)
#line 791 "mdbcomp.rtti_access.c"
{
#line 793 "mdbcomp.rtti_access.c"
  {
#line 795 "mdbcomp.rtti_access.c"
    MR_Word mdbcomp__rtti_access__conv0_HeadVar__1_1;

#line 798 "mdbcomp.rtti_access.c"
    {
#line 800 "mdbcomp.rtti_access.c"
      mdbcomp__rtti_access____Compare____bytecode_bytes_0_0(&mdbcomp__rtti_access__conv0_HeadVar__1_1, ((MR_Box) mdbcomp__rtti_access__wrapper_arg_2), ((MR_Box) mdbcomp__rtti_access__wrapper_arg_3));
    }
#line 803 "mdbcomp.rtti_access.c"
    *mdbcomp__rtti_access__wrapper_arg_1 = ((MR_Box) (mdbcomp__rtti_access__conv0_HeadVar__1_1));
#line 805 "mdbcomp.rtti_access.c"
  }
#line 807 "mdbcomp.rtti_access.c"
}

#line 810 "mdbcomp.rtti_access.c"
static MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____label_layout_0_0_10001(
#line 813 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1,
#line 815 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2)
#line 817 "mdbcomp.rtti_access.c"
{
#line 819 "mdbcomp.rtti_access.c"
  {
#line 821 "mdbcomp.rtti_access.c"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 824 "mdbcomp.rtti_access.c"
    {
#line 826 "mdbcomp.rtti_access.c"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access____Unify____label_layout_0_0(((MR_Box) mdbcomp__rtti_access__wrapper_arg_1), ((MR_Box) mdbcomp__rtti_access__wrapper_arg_2));
    }
#line 829 "mdbcomp.rtti_access.c"
    return mdbcomp__rtti_access__succeeded;
#line 831 "mdbcomp.rtti_access.c"
  }
#line 833 "mdbcomp.rtti_access.c"
}

#line 836 "mdbcomp.rtti_access.c"
static void MR_CALL 
mdbcomp__rtti_access____Compare____label_layout_0_0_10001(
#line 839 "mdbcomp.rtti_access.c"
  MR_Box * mdbcomp__rtti_access__wrapper_arg_1,
#line 841 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2,
#line 843 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_3)
#line 845 "mdbcomp.rtti_access.c"
{
#line 847 "mdbcomp.rtti_access.c"
  {
#line 849 "mdbcomp.rtti_access.c"
    MR_Word mdbcomp__rtti_access__conv0_HeadVar__1_1;

#line 852 "mdbcomp.rtti_access.c"
    {
#line 854 "mdbcomp.rtti_access.c"
      mdbcomp__rtti_access____Compare____label_layout_0_0(&mdbcomp__rtti_access__conv0_HeadVar__1_1, ((MR_Box) mdbcomp__rtti_access__wrapper_arg_2), ((MR_Box) mdbcomp__rtti_access__wrapper_arg_3));
    }
#line 857 "mdbcomp.rtti_access.c"
    *mdbcomp__rtti_access__wrapper_arg_1 = ((MR_Box) (mdbcomp__rtti_access__conv0_HeadVar__1_1));
#line 859 "mdbcomp.rtti_access.c"
  }
#line 861 "mdbcomp.rtti_access.c"
}

#line 864 "mdbcomp.rtti_access.c"
static MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____module_layout_0_0_10001(
#line 867 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1,
#line 869 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2)
#line 871 "mdbcomp.rtti_access.c"
{
#line 873 "mdbcomp.rtti_access.c"
  {
#line 875 "mdbcomp.rtti_access.c"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 878 "mdbcomp.rtti_access.c"
    {
#line 880 "mdbcomp.rtti_access.c"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access____Unify____module_layout_0_0(((MR_Box) mdbcomp__rtti_access__wrapper_arg_1), ((MR_Box) mdbcomp__rtti_access__wrapper_arg_2));
    }
#line 883 "mdbcomp.rtti_access.c"
    return mdbcomp__rtti_access__succeeded;
#line 885 "mdbcomp.rtti_access.c"
  }
#line 887 "mdbcomp.rtti_access.c"
}

#line 890 "mdbcomp.rtti_access.c"
static void MR_CALL 
mdbcomp__rtti_access____Compare____module_layout_0_0_10001(
#line 893 "mdbcomp.rtti_access.c"
  MR_Box * mdbcomp__rtti_access__wrapper_arg_1,
#line 895 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2,
#line 897 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_3)
#line 899 "mdbcomp.rtti_access.c"
{
#line 901 "mdbcomp.rtti_access.c"
  {
#line 903 "mdbcomp.rtti_access.c"
    MR_Word mdbcomp__rtti_access__conv0_HeadVar__1_1;

#line 906 "mdbcomp.rtti_access.c"
    {
#line 908 "mdbcomp.rtti_access.c"
      mdbcomp__rtti_access____Compare____module_layout_0_0(&mdbcomp__rtti_access__conv0_HeadVar__1_1, ((MR_Box) mdbcomp__rtti_access__wrapper_arg_2), ((MR_Box) mdbcomp__rtti_access__wrapper_arg_3));
    }
#line 911 "mdbcomp.rtti_access.c"
    *mdbcomp__rtti_access__wrapper_arg_1 = ((MR_Box) (mdbcomp__rtti_access__conv0_HeadVar__1_1));
#line 913 "mdbcomp.rtti_access.c"
  }
#line 915 "mdbcomp.rtti_access.c"
}

#line 918 "mdbcomp.rtti_access.c"
static MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____proc_layout_0_0_10001(
#line 921 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1,
#line 923 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2)
#line 925 "mdbcomp.rtti_access.c"
{
#line 927 "mdbcomp.rtti_access.c"
  {
#line 929 "mdbcomp.rtti_access.c"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 932 "mdbcomp.rtti_access.c"
    {
#line 934 "mdbcomp.rtti_access.c"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access____Unify____proc_layout_0_0(((MR_Box) mdbcomp__rtti_access__wrapper_arg_1), ((MR_Box) mdbcomp__rtti_access__wrapper_arg_2));
    }
#line 937 "mdbcomp.rtti_access.c"
    return mdbcomp__rtti_access__succeeded;
#line 939 "mdbcomp.rtti_access.c"
  }
#line 941 "mdbcomp.rtti_access.c"
}

#line 944 "mdbcomp.rtti_access.c"
static void MR_CALL 
mdbcomp__rtti_access____Compare____proc_layout_0_0_10001(
#line 947 "mdbcomp.rtti_access.c"
  MR_Box * mdbcomp__rtti_access__wrapper_arg_1,
#line 949 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2,
#line 951 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_3)
#line 953 "mdbcomp.rtti_access.c"
{
#line 955 "mdbcomp.rtti_access.c"
  {
#line 957 "mdbcomp.rtti_access.c"
    MR_Word mdbcomp__rtti_access__conv0_HeadVar__1_1;

#line 960 "mdbcomp.rtti_access.c"
    {
#line 962 "mdbcomp.rtti_access.c"
      mdbcomp__rtti_access____Compare____proc_layout_0_0(&mdbcomp__rtti_access__conv0_HeadVar__1_1, ((MR_Box) mdbcomp__rtti_access__wrapper_arg_2), ((MR_Box) mdbcomp__rtti_access__wrapper_arg_3));
    }
#line 965 "mdbcomp.rtti_access.c"
    *mdbcomp__rtti_access__wrapper_arg_1 = ((MR_Box) (mdbcomp__rtti_access__conv0_HeadVar__1_1));
#line 967 "mdbcomp.rtti_access.c"
  }
#line 969 "mdbcomp.rtti_access.c"
}

#line 972 "mdbcomp.rtti_access.c"
static MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____string_table_0_0_10001(
#line 975 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1,
#line 977 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2)
#line 979 "mdbcomp.rtti_access.c"
{
#line 981 "mdbcomp.rtti_access.c"
  {
#line 983 "mdbcomp.rtti_access.c"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 986 "mdbcomp.rtti_access.c"
    {
#line 988 "mdbcomp.rtti_access.c"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access____Unify____string_table_0_0(((MR_Word) mdbcomp__rtti_access__wrapper_arg_1), ((MR_Word) mdbcomp__rtti_access__wrapper_arg_2));
    }
#line 991 "mdbcomp.rtti_access.c"
    return mdbcomp__rtti_access__succeeded;
#line 993 "mdbcomp.rtti_access.c"
  }
#line 995 "mdbcomp.rtti_access.c"
}

#line 998 "mdbcomp.rtti_access.c"
static void MR_CALL 
mdbcomp__rtti_access____Compare____string_table_0_0_10001(
#line 1001 "mdbcomp.rtti_access.c"
  MR_Box * mdbcomp__rtti_access__wrapper_arg_1,
#line 1003 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2,
#line 1005 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_3)
#line 1007 "mdbcomp.rtti_access.c"
{
#line 1009 "mdbcomp.rtti_access.c"
  {
#line 1011 "mdbcomp.rtti_access.c"
    MR_Word mdbcomp__rtti_access__conv0_HeadVar__1_1;

#line 1014 "mdbcomp.rtti_access.c"
    {
#line 1016 "mdbcomp.rtti_access.c"
      mdbcomp__rtti_access____Compare____string_table_0_0(&mdbcomp__rtti_access__conv0_HeadVar__1_1, ((MR_Word) mdbcomp__rtti_access__wrapper_arg_2), ((MR_Word) mdbcomp__rtti_access__wrapper_arg_3));
    }
#line 1019 "mdbcomp.rtti_access.c"
    *mdbcomp__rtti_access__wrapper_arg_1 = ((MR_Box) (mdbcomp__rtti_access__conv0_HeadVar__1_1));
#line 1021 "mdbcomp.rtti_access.c"
  }
#line 1023 "mdbcomp.rtti_access.c"
}

#line 1026 "mdbcomp.rtti_access.c"
static MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____string_table_chars_0_0_10001(
#line 1029 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1,
#line 1031 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2)
#line 1033 "mdbcomp.rtti_access.c"
{
#line 1035 "mdbcomp.rtti_access.c"
  {
#line 1037 "mdbcomp.rtti_access.c"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 1040 "mdbcomp.rtti_access.c"
    {
#line 1042 "mdbcomp.rtti_access.c"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access____Unify____string_table_chars_0_0(((MR_Box) mdbcomp__rtti_access__wrapper_arg_1), ((MR_Box) mdbcomp__rtti_access__wrapper_arg_2));
    }
#line 1045 "mdbcomp.rtti_access.c"
    return mdbcomp__rtti_access__succeeded;
#line 1047 "mdbcomp.rtti_access.c"
  }
#line 1049 "mdbcomp.rtti_access.c"
}

#line 1052 "mdbcomp.rtti_access.c"
static void MR_CALL 
mdbcomp__rtti_access____Compare____string_table_chars_0_0_10001(
#line 1055 "mdbcomp.rtti_access.c"
  MR_Box * mdbcomp__rtti_access__wrapper_arg_1,
#line 1057 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_2,
#line 1059 "mdbcomp.rtti_access.c"
  MR_Box mdbcomp__rtti_access__wrapper_arg_3)
#line 1061 "mdbcomp.rtti_access.c"
{
#line 1063 "mdbcomp.rtti_access.c"
  {
#line 1065 "mdbcomp.rtti_access.c"
    MR_Word mdbcomp__rtti_access__conv0_HeadVar__1_1;

#line 1068 "mdbcomp.rtti_access.c"
    {
#line 1070 "mdbcomp.rtti_access.c"
      mdbcomp__rtti_access____Compare____string_table_chars_0_0(&mdbcomp__rtti_access__conv0_HeadVar__1_1, ((MR_Box) mdbcomp__rtti_access__wrapper_arg_2), ((MR_Box) mdbcomp__rtti_access__wrapper_arg_3));
    }
#line 1073 "mdbcomp.rtti_access.c"
    *mdbcomp__rtti_access__wrapper_arg_1 = ((MR_Box) (mdbcomp__rtti_access__conv0_HeadVar__1_1));
#line 1075 "mdbcomp.rtti_access.c"
  }
#line 1077 "mdbcomp.rtti_access.c"
}

#line 785 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__f_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_98_121_116_101_99_111_100_101_95_115_116_114_105_110_103_95_116_97_98_108_101_95_50_95_95_91_49_44_32_50_93_95_48_4_p_0(
#line 785 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__1_1,
#line 785 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__2_2,
#line 785 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__3_3,
#line 785 "rtti_access.m"
  MR_Box * mdbcomp__rtti_access__HeadVar__4_4)
#line 785 "rtti_access.m"
{
#line 788 "rtti_access.m"
  {
#line 788 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 788 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__TypeInfo_for_Offset_7;
#line 788 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__TypeInfo_for_Size_8;

#line 792 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__f_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_98_121_116_101_99_111_100_101_95_115_116_114_105_110_103_95_116_97_98_108_101_95_50_95_95_91_49_44_32_50_93_95_48_4_p_0

	const MR_uint_least8_t * Bytes;
	MR_Word Offset;
	MR_Word Size;
	MR_ConstString StringTableChars;

	Bytes = (const MR_uint_least8_t *) mdbcomp__rtti_access__HeadVar__1_1 ;
	Offset = (MR_Word) mdbcomp__rtti_access__HeadVar__2_2 ;
	Size = (MR_Word) mdbcomp__rtti_access__HeadVar__3_3 ;
		{
#line 792 "rtti_access.m"

    char        *buf;
    char        *table;
    MR_Unsigned i;

    MR_allocate_aligned_string_msg(buf, Size, MR_ALLOC_ID);
    table = ((char *) Bytes) + Offset;
    for (i = 0; i < Size; i++) {
        buf[i] = table[i];
    }

    StringTableChars = (MR_ConstString) buf;

#line 1129 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 *mdbcomp__rtti_access__HeadVar__4_4  = (MR_Box) StringTableChars;
#line 792 "rtti_access.m"
}
#line 788 "rtti_access.m"
  }
#line 785 "rtti_access.m"
}

#line 622 "rtti_access.m"
void MR_CALL 
mdbcomp__rtti_access____Compare____string_table_chars_0_0(
#line 622 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__HeadVar__1_1,
#line 622 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__2_2,
#line 622 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__3_3)
#line 622 "rtti_access.m"
{
#line 622 "rtti_access.m"
  {
#line 622 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 622 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar1_4 = (MR_Word) mdbcomp__rtti_access__HeadVar__2_2;
#line 622 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar2_5 = (MR_Word) mdbcomp__rtti_access__HeadVar__3_3;

#line 622 "rtti_access.m"
    {
#line 622 "rtti_access.m"
      mercury__builtin____Compare____c_pointer_0_0(mdbcomp__rtti_access__HeadVar__1_1, mdbcomp__rtti_access__Cast_HeadVar1_4, mdbcomp__rtti_access__Cast_HeadVar2_5);
#line 622 "rtti_access.m"
      return;
    }
#line 622 "rtti_access.m"
  }
#line 622 "rtti_access.m"
}

#line 622 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____string_table_chars_0_0(
#line 622 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__1_1,
#line 622 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__2_2)
#line 622 "rtti_access.m"
{
#line 622 "rtti_access.m"
  {
#line 622 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 622 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar1_3 = (MR_Word) mdbcomp__rtti_access__HeadVar__1_1;
#line 622 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar2_4 = (MR_Word) mdbcomp__rtti_access__HeadVar__2_2;

#line 622 "rtti_access.m"
    {
#line 622 "rtti_access.m"
      return mdbcomp__rtti_access__succeeded = mercury__builtin____Unify____c_pointer_0_0(mdbcomp__rtti_access__Cast_HeadVar1_3, mdbcomp__rtti_access__Cast_HeadVar2_4);
    }
#line 622 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 622 "rtti_access.m"
  }
#line 622 "rtti_access.m"
}

#line 77 "rtti_access.m"
void MR_CALL 
mdbcomp__rtti_access____Compare____string_table_0_0(
#line 77 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__HeadVar__1_1,
#line 77 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__HeadVar__2_2,
#line 77 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__HeadVar__3_3)
#line 77 "rtti_access.m"
{
#line 77 "rtti_access.m"
  {
#line 77 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 77 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__CastX_9 = (MR_Integer) mdbcomp__rtti_access__HeadVar__2_2;
#line 77 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__CastY_10 = (MR_Integer) mdbcomp__rtti_access__HeadVar__3_3;

#line 77 "rtti_access.m"
    mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__CastX_9 == mdbcomp__rtti_access__CastY_10);
#line 77 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 1227 "mdbcomp.rtti_access.c"
      *mdbcomp__rtti_access__HeadVar__1_1 = (MR_Integer) 0;
#line 77 "rtti_access.m"
    else
#line 77 "rtti_access.m"
      {
#line 77 "rtti_access.m"
        MR_Box mdbcomp__rtti_access__V_4_4 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__2_2, (MR_Integer) 0)));
#line 77 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_5_5 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__2_2, (MR_Integer) 1)));
#line 77 "rtti_access.m"
        MR_Box mdbcomp__rtti_access__V_6_6 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__3_3, (MR_Integer) 0)));
#line 77 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_7_7 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__3_3, (MR_Integer) 1)));
#line 77 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__V_8_8;
#line 77 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__Cast_HeadVar1_13 = (MR_Word) mdbcomp__rtti_access__V_4_4;
#line 77 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__Cast_HeadVar2_14 = (MR_Word) mdbcomp__rtti_access__V_6_6;

#line 622 "rtti_access.m"
        {
#line 622 "rtti_access.m"
          mercury__builtin____Compare____c_pointer_0_0(&mdbcomp__rtti_access__V_8_8, mdbcomp__rtti_access__Cast_HeadVar1_13, mdbcomp__rtti_access__Cast_HeadVar2_14);
        }
#line 1253 "mdbcomp.rtti_access.c"
        mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__V_8_8 == (MR_Integer) 0);
#line 77 "rtti_access.m"
        mdbcomp__rtti_access__succeeded = !(mdbcomp__rtti_access__succeeded);
#line 77 "rtti_access.m"
        if (mdbcomp__rtti_access__succeeded)
#line 77 "rtti_access.m"
          *mdbcomp__rtti_access__HeadVar__1_1 = mdbcomp__rtti_access__V_8_8;
#line 77 "rtti_access.m"
        else
#line 77 "rtti_access.m"
          {
#line 77 "rtti_access.m"
            mercury__private_builtin__builtin_compare_int_3_p_0(mdbcomp__rtti_access__HeadVar__1_1, mdbcomp__rtti_access__V_5_5, mdbcomp__rtti_access__V_7_7);
#line 77 "rtti_access.m"
            return;
          }
#line 77 "rtti_access.m"
      }
#line 77 "rtti_access.m"
  }
#line 77 "rtti_access.m"
}

#line 77 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____string_table_0_0(
#line 77 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__HeadVar__1_1,
#line 77 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__HeadVar__2_2)
#line 77 "rtti_access.m"
{
#line 77 "rtti_access.m"
  {
#line 77 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 77 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__CastX_7 = (MR_Integer) mdbcomp__rtti_access__HeadVar__1_1;
#line 77 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__CastY_8 = (MR_Integer) mdbcomp__rtti_access__HeadVar__2_2;

#line 77 "rtti_access.m"
    mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__CastX_7 == mdbcomp__rtti_access__CastY_8);
#line 77 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 77 "rtti_access.m"
      mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 77 "rtti_access.m"
    else
#line 77 "rtti_access.m"
      {
#line 77 "rtti_access.m"
        MR_Box mdbcomp__rtti_access__V_3_3 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 0)));
#line 77 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_4_4 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 1)));
#line 77 "rtti_access.m"
        MR_Box mdbcomp__rtti_access__V_5_5 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__2_2, (MR_Integer) 0)));
#line 77 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_6_6 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__2_2, (MR_Integer) 1)));
#line 77 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__Cast_HeadVar1_9 = (MR_Word) mdbcomp__rtti_access__V_3_3;
#line 77 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__Cast_HeadVar2_10 = (MR_Word) mdbcomp__rtti_access__V_5_5;

#line 622 "rtti_access.m"
        {
#line 622 "rtti_access.m"
          mdbcomp__rtti_access__succeeded = mercury__builtin____Unify____c_pointer_0_0(mdbcomp__rtti_access__Cast_HeadVar1_9, mdbcomp__rtti_access__Cast_HeadVar2_10);
        }
#line 77 "rtti_access.m"
        if (mdbcomp__rtti_access__succeeded)
#line 1325 "mdbcomp.rtti_access.c"
          mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__V_4_4 == mdbcomp__rtti_access__V_6_6);
#line 77 "rtti_access.m"
      }
#line 77 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 77 "rtti_access.m"
  }
#line 77 "rtti_access.m"
}

#line 261 "rtti_access.m"
void MR_CALL 
mdbcomp__rtti_access____Compare____proc_layout_0_0(
#line 261 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__HeadVar__1_1,
#line 261 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__2_2,
#line 261 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__3_3)
#line 261 "rtti_access.m"
{
#line 261 "rtti_access.m"
  {
#line 261 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 261 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar1_4 = (MR_Word) mdbcomp__rtti_access__HeadVar__2_2;
#line 261 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar2_5 = (MR_Word) mdbcomp__rtti_access__HeadVar__3_3;

#line 261 "rtti_access.m"
    {
#line 261 "rtti_access.m"
      mercury__builtin____Compare____c_pointer_0_0(mdbcomp__rtti_access__HeadVar__1_1, mdbcomp__rtti_access__Cast_HeadVar1_4, mdbcomp__rtti_access__Cast_HeadVar2_5);
#line 261 "rtti_access.m"
      return;
    }
#line 261 "rtti_access.m"
  }
#line 261 "rtti_access.m"
}

#line 261 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____proc_layout_0_0(
#line 261 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__1_1,
#line 261 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__2_2)
#line 261 "rtti_access.m"
{
#line 261 "rtti_access.m"
  {
#line 261 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 261 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar1_3 = (MR_Word) mdbcomp__rtti_access__HeadVar__1_1;
#line 261 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar2_4 = (MR_Word) mdbcomp__rtti_access__HeadVar__2_2;

#line 261 "rtti_access.m"
    {
#line 261 "rtti_access.m"
      return mdbcomp__rtti_access__succeeded = mercury__builtin____Unify____c_pointer_0_0(mdbcomp__rtti_access__Cast_HeadVar1_3, mdbcomp__rtti_access__Cast_HeadVar2_4);
    }
#line 261 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 261 "rtti_access.m"
  }
#line 261 "rtti_access.m"
}

#line 615 "rtti_access.m"
void MR_CALL 
mdbcomp__rtti_access____Compare____module_layout_0_0(
#line 615 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__HeadVar__1_1,
#line 615 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__2_2,
#line 615 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__3_3)
#line 615 "rtti_access.m"
{
#line 615 "rtti_access.m"
  {
#line 615 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 615 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar1_4 = (MR_Word) mdbcomp__rtti_access__HeadVar__2_2;
#line 615 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar2_5 = (MR_Word) mdbcomp__rtti_access__HeadVar__3_3;

#line 615 "rtti_access.m"
    {
#line 615 "rtti_access.m"
      mercury__builtin____Compare____c_pointer_0_0(mdbcomp__rtti_access__HeadVar__1_1, mdbcomp__rtti_access__Cast_HeadVar1_4, mdbcomp__rtti_access__Cast_HeadVar2_5);
#line 615 "rtti_access.m"
      return;
    }
#line 615 "rtti_access.m"
  }
#line 615 "rtti_access.m"
}

#line 615 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____module_layout_0_0(
#line 615 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__1_1,
#line 615 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__2_2)
#line 615 "rtti_access.m"
{
#line 615 "rtti_access.m"
  {
#line 615 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 615 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar1_3 = (MR_Word) mdbcomp__rtti_access__HeadVar__1_1;
#line 615 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar2_4 = (MR_Word) mdbcomp__rtti_access__HeadVar__2_2;

#line 615 "rtti_access.m"
    {
#line 615 "rtti_access.m"
      return mdbcomp__rtti_access__succeeded = mercury__builtin____Unify____c_pointer_0_0(mdbcomp__rtti_access__Cast_HeadVar1_3, mdbcomp__rtti_access__Cast_HeadVar2_4);
    }
#line 615 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 615 "rtti_access.m"
  }
#line 615 "rtti_access.m"
}

#line 207 "rtti_access.m"
void MR_CALL 
mdbcomp__rtti_access____Compare____label_layout_0_0(
#line 207 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__HeadVar__1_1,
#line 207 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__2_2,
#line 207 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__3_3)
#line 207 "rtti_access.m"
{
#line 207 "rtti_access.m"
  {
#line 207 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 207 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar1_4 = (MR_Word) mdbcomp__rtti_access__HeadVar__2_2;
#line 207 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar2_5 = (MR_Word) mdbcomp__rtti_access__HeadVar__3_3;

#line 207 "rtti_access.m"
    {
#line 207 "rtti_access.m"
      mercury__builtin____Compare____c_pointer_0_0(mdbcomp__rtti_access__HeadVar__1_1, mdbcomp__rtti_access__Cast_HeadVar1_4, mdbcomp__rtti_access__Cast_HeadVar2_5);
#line 207 "rtti_access.m"
      return;
    }
#line 207 "rtti_access.m"
  }
#line 207 "rtti_access.m"
}

#line 207 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____label_layout_0_0(
#line 207 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__1_1,
#line 207 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__2_2)
#line 207 "rtti_access.m"
{
#line 207 "rtti_access.m"
  {
#line 207 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 207 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar1_3 = (MR_Word) mdbcomp__rtti_access__HeadVar__1_1;
#line 207 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar2_4 = (MR_Word) mdbcomp__rtti_access__HeadVar__2_2;

#line 207 "rtti_access.m"
    {
#line 207 "rtti_access.m"
      return mdbcomp__rtti_access__succeeded = mercury__builtin____Unify____c_pointer_0_0(mdbcomp__rtti_access__Cast_HeadVar1_3, mdbcomp__rtti_access__Cast_HeadVar2_4);
    }
#line 207 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 207 "rtti_access.m"
  }
#line 207 "rtti_access.m"
}

#line 113 "rtti_access.m"
void MR_CALL 
mdbcomp__rtti_access____Compare____bytecode_bytes_0_0(
#line 113 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__HeadVar__1_1,
#line 113 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__2_2,
#line 113 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__3_3)
#line 113 "rtti_access.m"
{
#line 113 "rtti_access.m"
  {
#line 113 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 113 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar1_4 = (MR_Word) mdbcomp__rtti_access__HeadVar__2_2;
#line 113 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar2_5 = (MR_Word) mdbcomp__rtti_access__HeadVar__3_3;

#line 113 "rtti_access.m"
    {
#line 113 "rtti_access.m"
      mercury__builtin____Compare____c_pointer_0_0(mdbcomp__rtti_access__HeadVar__1_1, mdbcomp__rtti_access__Cast_HeadVar1_4, mdbcomp__rtti_access__Cast_HeadVar2_5);
#line 113 "rtti_access.m"
      return;
    }
#line 113 "rtti_access.m"
  }
#line 113 "rtti_access.m"
}

#line 113 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____bytecode_bytes_0_0(
#line 113 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__1_1,
#line 113 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__2_2)
#line 113 "rtti_access.m"
{
#line 113 "rtti_access.m"
  {
#line 113 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 113 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar1_3 = (MR_Word) mdbcomp__rtti_access__HeadVar__1_1;
#line 113 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Cast_HeadVar2_4 = (MR_Word) mdbcomp__rtti_access__HeadVar__2_2;

#line 113 "rtti_access.m"
    {
#line 113 "rtti_access.m"
      return mdbcomp__rtti_access__succeeded = mercury__builtin____Unify____c_pointer_0_0(mdbcomp__rtti_access__Cast_HeadVar1_3, mdbcomp__rtti_access__Cast_HeadVar2_4);
    }
#line 113 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 113 "rtti_access.m"
  }
#line 113 "rtti_access.m"
}

#line 99 "rtti_access.m"
void MR_CALL 
mdbcomp__rtti_access____Compare____bytecode_0_0(
#line 99 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__HeadVar__1_1,
#line 99 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__HeadVar__2_2,
#line 99 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__HeadVar__3_3)
#line 99 "rtti_access.m"
{
#line 99 "rtti_access.m"
  {
#line 99 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 99 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__CastX_9 = (MR_Integer) mdbcomp__rtti_access__HeadVar__2_2;
#line 99 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__CastY_10 = (MR_Integer) mdbcomp__rtti_access__HeadVar__3_3;

#line 99 "rtti_access.m"
    mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__CastX_9 == mdbcomp__rtti_access__CastY_10);
#line 99 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 1608 "mdbcomp.rtti_access.c"
      *mdbcomp__rtti_access__HeadVar__1_1 = (MR_Integer) 0;
#line 99 "rtti_access.m"
    else
#line 99 "rtti_access.m"
      {
#line 99 "rtti_access.m"
        MR_Box mdbcomp__rtti_access__V_4_4 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__2_2, (MR_Integer) 0)));
#line 99 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_5_5 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__2_2, (MR_Integer) 1)));
#line 99 "rtti_access.m"
        MR_Box mdbcomp__rtti_access__V_6_6 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__3_3, (MR_Integer) 0)));
#line 99 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_7_7 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__3_3, (MR_Integer) 1)));
#line 99 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__V_8_8;
#line 99 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__Cast_HeadVar1_13 = (MR_Word) mdbcomp__rtti_access__V_4_4;
#line 99 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__Cast_HeadVar2_14 = (MR_Word) mdbcomp__rtti_access__V_6_6;

#line 113 "rtti_access.m"
        {
#line 113 "rtti_access.m"
          mercury__builtin____Compare____c_pointer_0_0(&mdbcomp__rtti_access__V_8_8, mdbcomp__rtti_access__Cast_HeadVar1_13, mdbcomp__rtti_access__Cast_HeadVar2_14);
        }
#line 1634 "mdbcomp.rtti_access.c"
        mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__V_8_8 == (MR_Integer) 0);
#line 99 "rtti_access.m"
        mdbcomp__rtti_access__succeeded = !(mdbcomp__rtti_access__succeeded);
#line 99 "rtti_access.m"
        if (mdbcomp__rtti_access__succeeded)
#line 99 "rtti_access.m"
          *mdbcomp__rtti_access__HeadVar__1_1 = mdbcomp__rtti_access__V_8_8;
#line 99 "rtti_access.m"
        else
#line 99 "rtti_access.m"
          {
#line 99 "rtti_access.m"
            mercury__private_builtin__builtin_compare_int_3_p_0(mdbcomp__rtti_access__HeadVar__1_1, mdbcomp__rtti_access__V_5_5, mdbcomp__rtti_access__V_7_7);
#line 99 "rtti_access.m"
            return;
          }
#line 99 "rtti_access.m"
      }
#line 99 "rtti_access.m"
  }
#line 99 "rtti_access.m"
}

#line 99 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access____Unify____bytecode_0_0(
#line 99 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__HeadVar__1_1,
#line 99 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__HeadVar__2_2)
#line 99 "rtti_access.m"
{
#line 99 "rtti_access.m"
  {
#line 99 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 99 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__CastX_7 = (MR_Integer) mdbcomp__rtti_access__HeadVar__1_1;
#line 99 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__CastY_8 = (MR_Integer) mdbcomp__rtti_access__HeadVar__2_2;

#line 99 "rtti_access.m"
    mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__CastX_7 == mdbcomp__rtti_access__CastY_8);
#line 99 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 99 "rtti_access.m"
      mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 99 "rtti_access.m"
    else
#line 99 "rtti_access.m"
      {
#line 99 "rtti_access.m"
        MR_Box mdbcomp__rtti_access__V_3_3 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 0)));
#line 99 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_4_4 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 1)));
#line 99 "rtti_access.m"
        MR_Box mdbcomp__rtti_access__V_5_5 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__2_2, (MR_Integer) 0)));
#line 99 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_6_6 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__2_2, (MR_Integer) 1)));
#line 99 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__Cast_HeadVar1_9 = (MR_Word) mdbcomp__rtti_access__V_3_3;
#line 99 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__Cast_HeadVar2_10 = (MR_Word) mdbcomp__rtti_access__V_5_5;

#line 113 "rtti_access.m"
        {
#line 113 "rtti_access.m"
          mdbcomp__rtti_access__succeeded = mercury__builtin____Unify____c_pointer_0_0(mdbcomp__rtti_access__Cast_HeadVar1_9, mdbcomp__rtti_access__Cast_HeadVar2_10);
        }
#line 99 "rtti_access.m"
        if (mdbcomp__rtti_access__succeeded)
#line 1706 "mdbcomp.rtti_access.c"
          mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__V_4_4 == mdbcomp__rtti_access__V_6_6);
#line 99 "rtti_access.m"
      }
#line 99 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 99 "rtti_access.m"
  }
#line 99 "rtti_access.m"
}

#line 864 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__encode_num_2_3_p_0(
#line 864 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Num_4,
#line 864 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__RestBytes_5,
#line 864 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__Bytes_6)
#line 864 "rtti_access.m"
{
#line 869 "rtti_access.m"
  while (MR_TRUE)
#line 869 "rtti_access.m"
    {
#line 869 "rtti_access.m"
      /* tailcall optimized into a loop */
#line 869 "rtti_access.m"
      {
#line 869 "rtti_access.m"
        MR_bool mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__Num_4 == (MR_Integer) 0);

#line 869 "rtti_access.m"
        if (mdbcomp__rtti_access__succeeded)
#line 868 "rtti_access.m"
          *mdbcomp__rtti_access__Bytes_6 = mdbcomp__rtti_access__RestBytes_5;
#line 869 "rtti_access.m"
        else
#line 870 "rtti_access.m"
          {
#line 870 "rtti_access.m"
            MR_Integer mdbcomp__rtti_access__CurByte_7;
#line 870 "rtti_access.m"
            MR_Integer mdbcomp__rtti_access__NextNum_8;
#line 870 "rtti_access.m"
            MR_Integer mdbcomp__rtti_access__V_9_9 = (mdbcomp__rtti_access__Num_4 & (MR_Integer) 127);
#line 870 "rtti_access.m"
            MR_Word mdbcomp__rtti_access__V_13_13;

#line 870 "rtti_access.m"
            mdbcomp__rtti_access__CurByte_7 = (mdbcomp__rtti_access__V_9_9 | (MR_Integer) 128);
#line 871 "rtti_access.m"
            {
#line 871 "rtti_access.m"
              mdbcomp__rtti_access__NextNum_8 = mercury__int__f_slash_2_f_0(mdbcomp__rtti_access__Num_4, (MR_Integer) 128);
            }
#line 872 "rtti_access.m"
            {
#line 872 "rtti_access.m"
              mdbcomp__rtti_access__V_13_13 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), NULL, NULL));
#line 872 "rtti_access.m"
              MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__V_13_13, 0) = ((MR_Box) (mdbcomp__rtti_access__CurByte_7));
#line 872 "rtti_access.m"
              MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__V_13_13, 1) = ((MR_Box) (mdbcomp__rtti_access__RestBytes_5));
#line 872 "rtti_access.m"
            }
#line 872 "rtti_access.m"
            /* direct tailcall eliminated */
#line 872 "rtti_access.m"
            {
#line 872 "rtti_access.m"
              MR_Integer mdbcomp__rtti_access__Num__tmp_copy_4 = mdbcomp__rtti_access__NextNum_8;
#line 872 "rtti_access.m"
              MR_Word mdbcomp__rtti_access__RestBytes__tmp_copy_5 = mdbcomp__rtti_access__V_13_13;

#line 872 "rtti_access.m"
              mdbcomp__rtti_access__RestBytes_5 = mdbcomp__rtti_access__RestBytes__tmp_copy_5;
#line 872 "rtti_access.m"
              mdbcomp__rtti_access__Num_4 = mdbcomp__rtti_access__Num__tmp_copy_4;
#line 872 "rtti_access.m"
            }
#line 872 "rtti_access.m"
            continue;
#line 870 "rtti_access.m"
          }
#line 869 "rtti_access.m"
      }
#line 869 "rtti_access.m"
      break;
#line 869 "rtti_access.m"
    }
#line 864 "rtti_access.m"
}

#line 785 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__bytecode_string_table_2_4_p_0(
#line 785 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__TypeInfo_for_Offset_5,
#line 785 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__TypeInfo_for_Size_6,
#line 785 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__1_1,
#line 785 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__2_2,
#line 785 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__HeadVar__3_3,
#line 785 "rtti_access.m"
  MR_Box * mdbcomp__rtti_access__HeadVar__4_4)
#line 785 "rtti_access.m"
{
#line 788 "rtti_access.m"
  {
#line 788 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 788 "rtti_access.m"
    {
#line 788 "rtti_access.m"
      mdbcomp__rtti_access__f_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_98_121_116_101_99_111_100_101_95_115_116_114_105_110_103_95_116_97_98_108_101_95_50_95_95_91_49_44_32_50_93_95_48_4_p_0(mdbcomp__rtti_access__HeadVar__1_1, mdbcomp__rtti_access__HeadVar__2_2, mdbcomp__rtti_access__HeadVar__3_3, mdbcomp__rtti_access__HeadVar__4_4);
#line 788 "rtti_access.m"
      return;
    }
#line 788 "rtti_access.m"
  }
#line 785 "rtti_access.m"
}

#line 764 "rtti_access.m"
static MR_bool MR_CALL 
mdbcomp__rtti_access__read_len_string_2_6_p_0(
#line 764 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__ByteCode_7,
#line 764 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__N_8,
#line 764 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__STATE_VARIABLE_RevChars_0_13,
#line 764 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__STATE_VARIABLE_RevChars_14,
#line 764 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_15,
#line 764 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__STATE_VARIABLE_Pos_16)
#line 764 "rtti_access.m"
{
#line 770 "rtti_access.m"
  while (MR_TRUE)
#line 770 "rtti_access.m"
    {
#line 770 "rtti_access.m"
      /* tailcall optimized into a loop */
#line 770 "rtti_access.m"
      {
#line 770 "rtti_access.m"
        MR_bool mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__N_8 <= (MR_Integer) 0);

#line 770 "rtti_access.m"
        if (mdbcomp__rtti_access__succeeded)
#line 769 "rtti_access.m"
          {
#line 769 "rtti_access.m"
            *mdbcomp__rtti_access__STATE_VARIABLE_Pos_16 = mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_15;
#line 769 "rtti_access.m"
            *mdbcomp__rtti_access__STATE_VARIABLE_RevChars_14 = mdbcomp__rtti_access__STATE_VARIABLE_RevChars_0_13;
#line 769 "rtti_access.m"
            mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 769 "rtti_access.m"
          }
#line 770 "rtti_access.m"
        else
#line 771 "rtti_access.m"
          {
#line 771 "rtti_access.m"
            MR_Integer mdbcomp__rtti_access__Byte_11;
#line 771 "rtti_access.m"
            MR_Char mdbcomp__rtti_access__Char_12;
#line 771 "rtti_access.m"
            MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_18_18;
#line 771 "rtti_access.m"
            MR_Word mdbcomp__rtti_access__STATE_VARIABLE_RevChars_19_19;
#line 771 "rtti_access.m"
            MR_Integer mdbcomp__rtti_access__V_20_20;
#line 771 "rtti_access.m"
            MR_Integer mdbcomp__rtti_access__V_23_23;
#line 771 "rtti_access.m"
            MR_Box mdbcomp__rtti_access__Bytes_29 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_7, (MR_Integer) 0)));
#line 771 "rtti_access.m"
            MR_Integer mdbcomp__rtti_access__Size_30 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_7, (MR_Integer) 1)));
#line 771 "rtti_access.m"
            MR_Integer mdbcomp__rtti_access__V_31_31 = (mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_15 + (MR_Integer) 1);

#line 679 "rtti_access.m"
            mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__V_31_31 <= mdbcomp__rtti_access__Size_30);
#line 771 "rtti_access.m"
            if (mdbcomp__rtti_access__succeeded)
#line 771 "rtti_access.m"
              {
#line 687 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__read_len_string_2_6_p_0

	const MR_uint_least8_t * ByteCode;
	MR_Integer Value;
	MR_Integer Pos0;
	MR_Integer Pos;

	ByteCode = (const MR_uint_least8_t *) mdbcomp__rtti_access__Bytes_29 ;
	Pos0 =  mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_15 ;
		{
#line 687 "rtti_access.m"

    Value = ByteCode[Pos0];
    Pos = Pos0 + 1;

#line 1921 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__Byte_11  = Value;
	 mdbcomp__rtti_access__STATE_VARIABLE_Pos_18_18  = Pos;
#line 687 "rtti_access.m"
}
#line 772 "rtti_access.m"
                {
#line 772 "rtti_access.m"
                  mdbcomp__rtti_access__succeeded = mercury__char__from_int_2_p_0(mdbcomp__rtti_access__Byte_11, &mdbcomp__rtti_access__Char_12);
                }
#line 771 "rtti_access.m"
                if (mdbcomp__rtti_access__succeeded)
#line 771 "rtti_access.m"
                  {
#line 774 "rtti_access.m"
                    mdbcomp__rtti_access__V_23_23 = (MR_Integer) 1;
#line 774 "rtti_access.m"
                    mdbcomp__rtti_access__V_20_20 = (mdbcomp__rtti_access__N_8 - mdbcomp__rtti_access__V_23_23);
#line 773 "rtti_access.m"
                    {
#line 773 "rtti_access.m"
                      mdbcomp__rtti_access__STATE_VARIABLE_RevChars_19_19 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), NULL, NULL));
#line 773 "rtti_access.m"
                      MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__STATE_VARIABLE_RevChars_19_19, 0) = ((MR_Box) (MR_Word) (mdbcomp__rtti_access__Char_12));
#line 773 "rtti_access.m"
                      MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__STATE_VARIABLE_RevChars_19_19, 1) = ((MR_Box) (mdbcomp__rtti_access__STATE_VARIABLE_RevChars_0_13));
#line 773 "rtti_access.m"
                    }
#line 774 "rtti_access.m"
                    /* direct tailcall eliminated */
#line 774 "rtti_access.m"
                    {
#line 774 "rtti_access.m"
                      MR_Integer mdbcomp__rtti_access__N__tmp_copy_8 = mdbcomp__rtti_access__V_20_20;
#line 774 "rtti_access.m"
                      MR_Word mdbcomp__rtti_access__STATE_VARIABLE_RevChars_0__tmp_copy_13 = mdbcomp__rtti_access__STATE_VARIABLE_RevChars_19_19;
#line 774 "rtti_access.m"
                      MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0__tmp_copy_15 = mdbcomp__rtti_access__STATE_VARIABLE_Pos_18_18;

#line 774 "rtti_access.m"
                      mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_15 = mdbcomp__rtti_access__STATE_VARIABLE_Pos_0__tmp_copy_15;
#line 774 "rtti_access.m"
                      mdbcomp__rtti_access__STATE_VARIABLE_RevChars_0_13 = mdbcomp__rtti_access__STATE_VARIABLE_RevChars_0__tmp_copy_13;
#line 774 "rtti_access.m"
                      mdbcomp__rtti_access__N_8 = mdbcomp__rtti_access__N__tmp_copy_8;
#line 774 "rtti_access.m"
                    }
#line 774 "rtti_access.m"
                    continue;
#line 771 "rtti_access.m"
                  }
#line 771 "rtti_access.m"
              }
#line 771 "rtti_access.m"
          }
#line 770 "rtti_access.m"
        return mdbcomp__rtti_access__succeeded;
#line 770 "rtti_access.m"
      }
#line 770 "rtti_access.m"
      break;
#line 770 "rtti_access.m"
    }
#line 764 "rtti_access.m"
}

#line 746 "rtti_access.m"
static MR_bool MR_CALL 
mdbcomp__rtti_access__read_line_2_5_p_0(
#line 746 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__ByteCode_6,
#line 746 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__STATE_VARIABLE_RevChars_0_11,
#line 746 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__STATE_VARIABLE_RevChars_12,
#line 746 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_13,
#line 746 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__STATE_VARIABLE_Pos_14)
#line 746 "rtti_access.m"
{
#line 749 "rtti_access.m"
  while (MR_TRUE)
#line 749 "rtti_access.m"
    {
#line 749 "rtti_access.m"
      /* tailcall optimized into a loop */
#line 749 "rtti_access.m"
      {
#line 749 "rtti_access.m"
        MR_bool mdbcomp__rtti_access__succeeded;
#line 749 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__Byte_9;
#line 749 "rtti_access.m"
        MR_Char mdbcomp__rtti_access__Char_10;
#line 749 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_15_15;
#line 749 "rtti_access.m"
        MR_Box mdbcomp__rtti_access__Bytes_25 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_6, (MR_Integer) 0)));
#line 749 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__Size_26 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_6, (MR_Integer) 1)));
#line 749 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_27_27 = (mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_13 + (MR_Integer) 1);

#line 679 "rtti_access.m"
        mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__V_27_27 <= mdbcomp__rtti_access__Size_26);
#line 749 "rtti_access.m"
        if (mdbcomp__rtti_access__succeeded)
#line 749 "rtti_access.m"
          {
#line 687 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__read_line_2_5_p_0

	const MR_uint_least8_t * ByteCode;
	MR_Integer Value;
	MR_Integer Pos0;
	MR_Integer Pos;

	ByteCode = (const MR_uint_least8_t *) mdbcomp__rtti_access__Bytes_25 ;
	Pos0 =  mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_13 ;
		{
#line 687 "rtti_access.m"

    Value = ByteCode[Pos0];
    Pos = Pos0 + 1;

#line 2051 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__Byte_9  = Value;
	 mdbcomp__rtti_access__STATE_VARIABLE_Pos_15_15  = Pos;
#line 687 "rtti_access.m"
}
#line 751 "rtti_access.m"
            {
#line 751 "rtti_access.m"
              mdbcomp__rtti_access__succeeded = mercury__char__from_int_2_p_0(mdbcomp__rtti_access__Byte_9, &mdbcomp__rtti_access__Char_10);
            }
#line 749 "rtti_access.m"
            if (mdbcomp__rtti_access__succeeded)
#line 749 "rtti_access.m"
              {
#line 752 "rtti_access.m"
                mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__Char_10 == (MR_Char) 10);
#line 754 "rtti_access.m"
                if (mdbcomp__rtti_access__succeeded)
#line 753 "rtti_access.m"
                  {
#line 753 "rtti_access.m"
                    {
#line 753 "rtti_access.m"
                      MR_Word base;
#line 753 "rtti_access.m"
                      base = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), NULL, NULL));
#line 753 "rtti_access.m"
                      *mdbcomp__rtti_access__STATE_VARIABLE_RevChars_12 = base;
#line 753 "rtti_access.m"
                      MR_hl_field(MR_mktag(1), base, 0) = ((MR_Box) (MR_Word) (mdbcomp__rtti_access__Char_10));
#line 753 "rtti_access.m"
                      MR_hl_field(MR_mktag(1), base, 1) = ((MR_Box) (mdbcomp__rtti_access__STATE_VARIABLE_RevChars_0_11));
#line 753 "rtti_access.m"
                    }
#line 753 "rtti_access.m"
                    *mdbcomp__rtti_access__STATE_VARIABLE_Pos_14 = mdbcomp__rtti_access__STATE_VARIABLE_Pos_15_15;
#line 753 "rtti_access.m"
                    mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 753 "rtti_access.m"
                  }
#line 754 "rtti_access.m"
                else
#line 755 "rtti_access.m"
                  {
#line 755 "rtti_access.m"
                    MR_Word mdbcomp__rtti_access__STATE_VARIABLE_RevChars_17_17;

#line 755 "rtti_access.m"
                    {
#line 755 "rtti_access.m"
                      mdbcomp__rtti_access__STATE_VARIABLE_RevChars_17_17 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), NULL, NULL));
#line 755 "rtti_access.m"
                      MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__STATE_VARIABLE_RevChars_17_17, 0) = ((MR_Box) (MR_Word) (mdbcomp__rtti_access__Char_10));
#line 755 "rtti_access.m"
                      MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__STATE_VARIABLE_RevChars_17_17, 1) = ((MR_Box) (mdbcomp__rtti_access__STATE_VARIABLE_RevChars_0_11));
#line 755 "rtti_access.m"
                    }
#line 756 "rtti_access.m"
                    /* direct tailcall eliminated */
#line 756 "rtti_access.m"
                    {
#line 756 "rtti_access.m"
                      MR_Word mdbcomp__rtti_access__STATE_VARIABLE_RevChars_0__tmp_copy_11 = mdbcomp__rtti_access__STATE_VARIABLE_RevChars_17_17;
#line 756 "rtti_access.m"
                      MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0__tmp_copy_13 = mdbcomp__rtti_access__STATE_VARIABLE_Pos_15_15;

#line 756 "rtti_access.m"
                      mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_13 = mdbcomp__rtti_access__STATE_VARIABLE_Pos_0__tmp_copy_13;
#line 756 "rtti_access.m"
                      mdbcomp__rtti_access__STATE_VARIABLE_RevChars_0_11 = mdbcomp__rtti_access__STATE_VARIABLE_RevChars_0__tmp_copy_11;
#line 756 "rtti_access.m"
                    }
#line 756 "rtti_access.m"
                    continue;
#line 755 "rtti_access.m"
                  }
#line 749 "rtti_access.m"
              }
#line 749 "rtti_access.m"
          }
#line 749 "rtti_access.m"
        return mdbcomp__rtti_access__succeeded;
#line 749 "rtti_access.m"
      }
#line 749 "rtti_access.m"
      break;
#line 749 "rtti_access.m"
    }
#line 746 "rtti_access.m"
}

#line 726 "rtti_access.m"
static MR_bool MR_CALL 
mdbcomp__rtti_access__read_num_2_5_p_0(
#line 726 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__ByteCode_6,
#line 726 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Num0_7,
#line 726 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Num_8,
#line 726 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_12,
#line 726 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__STATE_VARIABLE_Pos_13)
#line 726 "rtti_access.m"
{
#line 729 "rtti_access.m"
  while (MR_TRUE)
#line 729 "rtti_access.m"
    {
#line 729 "rtti_access.m"
      /* tailcall optimized into a loop */
#line 729 "rtti_access.m"
      {
#line 729 "rtti_access.m"
        MR_bool mdbcomp__rtti_access__succeeded;
#line 729 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__Byte_10;
#line 729 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__Num1_11;
#line 729 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_14_14;
#line 729 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_15_15;
#line 729 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_16_16;
#line 729 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_17_17;
#line 729 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_18_18;
#line 729 "rtti_access.m"
        MR_Box mdbcomp__rtti_access__Bytes_27 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_6, (MR_Integer) 0)));
#line 729 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__Size_28 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_6, (MR_Integer) 1)));
#line 729 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_29_29 = (mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_12 + (MR_Integer) 1);
#line 732 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_19_19;
#line 732 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_20_20;

#line 679 "rtti_access.m"
        mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__V_29_29 <= mdbcomp__rtti_access__Size_28);
#line 729 "rtti_access.m"
        if (mdbcomp__rtti_access__succeeded)
#line 729 "rtti_access.m"
          {
#line 687 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__read_num_2_5_p_0

	const MR_uint_least8_t * ByteCode;
	MR_Integer Value;
	MR_Integer Pos0;
	MR_Integer Pos;

	ByteCode = (const MR_uint_least8_t *) mdbcomp__rtti_access__Bytes_27 ;
	Pos0 =  mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_12 ;
		{
#line 687 "rtti_access.m"

    Value = ByteCode[Pos0];
    Pos = Pos0 + 1;

#line 2218 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__Byte_10  = Value;
	 mdbcomp__rtti_access__STATE_VARIABLE_Pos_14_14  = Pos;
#line 687 "rtti_access.m"
}
#line 731 "rtti_access.m"
            mdbcomp__rtti_access__V_16_16 = (MR_Integer) 7;
#line 731 "rtti_access.m"
            {
#line 731 "rtti_access.m"
              mdbcomp__rtti_access__V_15_15 = mercury__int__f_60_60_2_f_0(mdbcomp__rtti_access__Num0_7, mdbcomp__rtti_access__V_16_16);
            }
#line 731 "rtti_access.m"
            mdbcomp__rtti_access__V_18_18 = (MR_Integer) 127;
#line 731 "rtti_access.m"
            mdbcomp__rtti_access__V_17_17 = (mdbcomp__rtti_access__Byte_10 & mdbcomp__rtti_access__V_18_18);
#line 731 "rtti_access.m"
            mdbcomp__rtti_access__Num1_11 = (mdbcomp__rtti_access__V_15_15 | mdbcomp__rtti_access__V_17_17);
#line 732 "rtti_access.m"
            mdbcomp__rtti_access__V_20_20 = (MR_Integer) 128;
#line 732 "rtti_access.m"
            mdbcomp__rtti_access__V_19_19 = (mdbcomp__rtti_access__Byte_10 & mdbcomp__rtti_access__V_20_20);
#line 732 "rtti_access.m"
            mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__V_19_19 == (MR_Integer) 0);
#line 732 "rtti_access.m"
            mdbcomp__rtti_access__succeeded = !(mdbcomp__rtti_access__succeeded);
#line 734 "rtti_access.m"
            if (mdbcomp__rtti_access__succeeded)
#line 733 "rtti_access.m"
              {
#line 733 "rtti_access.m"
                /* direct tailcall eliminated */
#line 733 "rtti_access.m"
                {
#line 733 "rtti_access.m"
                  MR_Integer mdbcomp__rtti_access__Num0__tmp_copy_7 = mdbcomp__rtti_access__Num1_11;
#line 733 "rtti_access.m"
                  MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0__tmp_copy_12 = mdbcomp__rtti_access__STATE_VARIABLE_Pos_14_14;

#line 733 "rtti_access.m"
                  mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_12 = mdbcomp__rtti_access__STATE_VARIABLE_Pos_0__tmp_copy_12;
#line 733 "rtti_access.m"
                  mdbcomp__rtti_access__Num0_7 = mdbcomp__rtti_access__Num0__tmp_copy_7;
#line 733 "rtti_access.m"
                }
#line 733 "rtti_access.m"
                continue;
#line 733 "rtti_access.m"
              }
#line 734 "rtti_access.m"
            else
#line 735 "rtti_access.m"
              {
#line 735 "rtti_access.m"
                *mdbcomp__rtti_access__Num_8 = mdbcomp__rtti_access__Num1_11;
#line 735 "rtti_access.m"
                *mdbcomp__rtti_access__STATE_VARIABLE_Pos_13 = mdbcomp__rtti_access__STATE_VARIABLE_Pos_14_14;
#line 735 "rtti_access.m"
                mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 735 "rtti_access.m"
              }
#line 729 "rtti_access.m"
          }
#line 729 "rtti_access.m"
        return mdbcomp__rtti_access__succeeded;
#line 729 "rtti_access.m"
      }
#line 729 "rtti_access.m"
      break;
#line 729 "rtti_access.m"
    }
#line 726 "rtti_access.m"
}

#line 712 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__read_int32_2_4_p_0(
#line 712 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__ByteCode_1,
#line 712 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Value_2,
#line 712 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Pos0_3,
#line 712 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Pos_4)
#line 712 "rtti_access.m"
{
#line 714 "rtti_access.m"
  {
#line 714 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 717 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__read_int32_2_4_p_0

	const MR_uint_least8_t * ByteCode;
	MR_Integer Value;
	MR_Integer Pos0;
	MR_Integer Pos;

	ByteCode = (const MR_uint_least8_t *) mdbcomp__rtti_access__ByteCode_1 ;
	Pos0 =  mdbcomp__rtti_access__Pos0_3 ;
		{
#line 717 "rtti_access.m"

    Value = (ByteCode[Pos0] << 24) + (ByteCode[Pos0+1] << 16) +
        (ByteCode[Pos0+2] << 8) + ByteCode[Pos0+3];
    Pos = Pos0 + 4;

#line 2331 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 *mdbcomp__rtti_access__Value_2  = Value;
	 *mdbcomp__rtti_access__Pos_4  = Pos;
#line 717 "rtti_access.m"
}
#line 714 "rtti_access.m"
  }
#line 712 "rtti_access.m"
}

#line 697 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__read_short_2_4_p_0(
#line 697 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__ByteCode_1,
#line 697 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Value_2,
#line 697 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Pos0_3,
#line 697 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Pos_4)
#line 697 "rtti_access.m"
{
#line 699 "rtti_access.m"
  {
#line 699 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 702 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__read_short_2_4_p_0

	const MR_uint_least8_t * ByteCode;
	MR_Integer Value;
	MR_Integer Pos0;
	MR_Integer Pos;

	ByteCode = (const MR_uint_least8_t *) mdbcomp__rtti_access__ByteCode_1 ;
	Pos0 =  mdbcomp__rtti_access__Pos0_3 ;
		{
#line 702 "rtti_access.m"

    Value = (ByteCode[Pos0] << 8) + ByteCode[Pos0+1];
    Pos = Pos0 + 2;

#line 2379 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 *mdbcomp__rtti_access__Value_2  = Value;
	 *mdbcomp__rtti_access__Pos_4  = Pos;
#line 702 "rtti_access.m"
}
#line 699 "rtti_access.m"
  }
#line 697 "rtti_access.m"
}

#line 682 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__read_byte_2_4_p_0(
#line 682 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__ByteCode_1,
#line 682 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Value_2,
#line 682 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Pos0_3,
#line 682 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Pos_4)
#line 682 "rtti_access.m"
{
#line 684 "rtti_access.m"
  {
#line 684 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 687 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__read_byte_2_4_p_0

	const MR_uint_least8_t * ByteCode;
	MR_Integer Value;
	MR_Integer Pos0;
	MR_Integer Pos;

	ByteCode = (const MR_uint_least8_t *) mdbcomp__rtti_access__ByteCode_1 ;
	Pos0 =  mdbcomp__rtti_access__Pos0_3 ;
		{
#line 687 "rtti_access.m"

    Value = ByteCode[Pos0];
    Pos = Pos0 + 1;

#line 2427 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 *mdbcomp__rtti_access__Value_2  = Value;
	 *mdbcomp__rtti_access__Pos_4  = Pos;
#line 687 "rtti_access.m"
}
#line 684 "rtti_access.m"
  }
#line 682 "rtti_access.m"
}

#line 656 "rtti_access.m"
static MR_String MR_CALL 
mdbcomp__rtti_access__lookup_string_table_2_3_f_0(
#line 656 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__StringTableChars_1,
#line 656 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__StringTableSize_2,
#line 656 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__NameCode_3)
#line 656 "rtti_access.m"
{
#line 658 "rtti_access.m"
  {
#line 658 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 658 "rtti_access.m"
    MR_String mdbcomp__rtti_access__Str_4;

#line 662 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__lookup_string_table_2_3_f_0

	MR_ConstString StringTableChars;
	MR_Integer StringTableSize;
	MR_Integer NameCode;
	MR_String Str;

	StringTableChars = (MR_ConstString) mdbcomp__rtti_access__StringTableChars_1 ;
	StringTableSize =  mdbcomp__rtti_access__StringTableSize_2 ;
	NameCode =  mdbcomp__rtti_access__NameCode_3 ;
		{
#line 662 "rtti_access.m"

    MR_ConstString  str0;
    int             should_copy;

    str0 = MR_name_in_string_table(StringTableChars, StringTableSize,
        (MR_uint_least32_t)NameCode, &should_copy);
    if (should_copy) {
        MR_make_aligned_string(Str, str0);
    } else {
        MR_make_aligned_string_copy(Str, str0);
    }

#line 2484 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__Str_4  = Str;
#line 662 "rtti_access.m"
}
#line 658 "rtti_access.m"
    return mdbcomp__rtti_access__Str_4;
#line 658 "rtti_access.m"
  }
#line 656 "rtti_access.m"
}

#line 640 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__module_string_table_components_3_p_0(
#line 640 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__ModuleLayout_1,
#line 640 "rtti_access.m"
  MR_Box * mdbcomp__rtti_access__StringTableChars_2,
#line 640 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Size_3)
#line 640 "rtti_access.m"
{
#line 643 "rtti_access.m"
  {
#line 643 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 647 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__module_string_table_components_3_p_0

	const MR_ModuleLayout * ModuleLayout;
	MR_ConstString StringTableChars;
	MR_Integer Size;

	ModuleLayout = (const MR_ModuleLayout *) mdbcomp__rtti_access__ModuleLayout_1 ;
		{
#line 647 "rtti_access.m"

    StringTableChars = ModuleLayout->MR_ml_string_table;
    Size = ModuleLayout->MR_ml_string_table_size;

#line 2529 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 *mdbcomp__rtti_access__StringTableChars_2  = (MR_Box) StringTableChars;
	 *mdbcomp__rtti_access__Size_3  = Size;
#line 647 "rtti_access.m"
}
#line 643 "rtti_access.m"
  }
#line 640 "rtti_access.m"
}

#line 322 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__proc_layout_get_non_uci_fields_7_p_0(
#line 322 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__Layout_1,
#line 322 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__PredOrFunc_2,
#line 322 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__DeclModule_3,
#line 322 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__DefModule_4,
#line 322 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__PredName_5,
#line 322 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Arity_6,
#line 322 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__ModeNum_7)
#line 322 "rtti_access.m"
{
#line 325 "rtti_access.m"
  {
#line 325 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 330 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__proc_layout_get_non_uci_fields_7_p_0

	const MR_ProcLayout * Layout;
	MR_Word PredOrFunc;
	MR_String DeclModule;
	MR_String DefModule;
	MR_String PredName;
	MR_Integer Arity;
	MR_Integer ModeNum;

	Layout = (const MR_ProcLayout *) mdbcomp__rtti_access__Layout_1 ;
		{
#line 330 "rtti_access.m"

    const MR_UserProcId *proc_id;

    proc_id = &Layout->MR_sle_user;

    /* The casts are there to cast away const without warnings */
    PredOrFunc = proc_id->MR_user_pred_or_func;
    DeclModule = (MR_String) (MR_Integer) proc_id->MR_user_decl_module;
    DefModule  = (MR_String) (MR_Integer) proc_id->MR_user_def_module;
    PredName   = (MR_String) (MR_Integer) proc_id->MR_user_name;
    Arity      = proc_id->MR_user_arity;
    ModeNum    = proc_id->MR_user_mode;

#line 2594 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 *mdbcomp__rtti_access__PredOrFunc_2  = PredOrFunc;
	 *mdbcomp__rtti_access__DeclModule_3  = DeclModule;
	 *mdbcomp__rtti_access__DefModule_4  = DefModule;
	 *mdbcomp__rtti_access__PredName_5  = PredName;
	 *mdbcomp__rtti_access__Arity_6  = Arity;
	 *mdbcomp__rtti_access__ModeNum_7  = ModeNum;
#line 330 "rtti_access.m"
}
#line 325 "rtti_access.m"
  }
#line 322 "rtti_access.m"
}

#line 301 "rtti_access.m"
static void MR_CALL 
mdbcomp__rtti_access__proc_layout_get_uci_fields_7_p_0(
#line 301 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__Layout_1,
#line 301 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__TypeName_2,
#line 301 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__TypeModule_3,
#line 301 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__DefModule_4,
#line 301 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__PredName_5,
#line 301 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__TypeArity_6,
#line 301 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__ModeNum_7)
#line 301 "rtti_access.m"
{
#line 304 "rtti_access.m"
  {
#line 304 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 308 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__proc_layout_get_uci_fields_7_p_0

	const MR_ProcLayout * Layout;
	MR_String TypeName;
	MR_String TypeModule;
	MR_String DefModule;
	MR_String PredName;
	MR_Integer TypeArity;
	MR_Integer ModeNum;

	Layout = (const MR_ProcLayout *) mdbcomp__rtti_access__Layout_1 ;
		{
#line 308 "rtti_access.m"

    const MR_UCIProcId  *proc_id;

    proc_id = &Layout->MR_sle_uci;

    /* The casts are there to cast away const without warnings */
    TypeName   = (MR_String) (MR_Integer) proc_id->MR_uci_type_name;
    TypeModule = (MR_String) (MR_Integer) proc_id->MR_uci_type_module;
    DefModule  = (MR_String) (MR_Integer) proc_id->MR_uci_def_module;
    PredName   = (MR_String) (MR_Integer) proc_id->MR_uci_pred_name;
    TypeArity  = proc_id->MR_uci_type_arity;
    ModeNum    = proc_id->MR_uci_mode;

#line 2663 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 *mdbcomp__rtti_access__TypeName_2  = TypeName;
	 *mdbcomp__rtti_access__TypeModule_3  = TypeModule;
	 *mdbcomp__rtti_access__DefModule_4  = DefModule;
	 *mdbcomp__rtti_access__PredName_5  = PredName;
	 *mdbcomp__rtti_access__TypeArity_6  = TypeArity;
	 *mdbcomp__rtti_access__ModeNum_7  = ModeNum;
#line 308 "rtti_access.m"
}
#line 304 "rtti_access.m"
  }
#line 301 "rtti_access.m"
}

#line 288 "rtti_access.m"
static MR_bool MR_CALL 
mdbcomp__rtti_access__proc_layout_is_uci_1_p_0(
#line 288 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__Layout_1)
#line 288 "rtti_access.m"
{
#line 290 "rtti_access.m"
  {
#line 290 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 293 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__proc_layout_is_uci_1_p_0

	const MR_ProcLayout * Layout;
	MR_bool SUCCESS_INDICATOR;

	Layout = (const MR_ProcLayout *) mdbcomp__rtti_access__Layout_1 ;
		{
#line 293 "rtti_access.m"

    if (MR_PROC_ID_IS_UCI(Layout->MR_sle_proc_id)) {
        SUCCESS_INDICATOR = MR_TRUE;
    } else {
        SUCCESS_INDICATOR = MR_FALSE;
    }

#line 2709 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	if (SUCCESS_INDICATOR) {
#line 293 "rtti_access.m"
	}
mdbcomp__rtti_access__succeeded  = SUCCESS_INDICATOR;
}
#line 290 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 290 "rtti_access.m"
  }
#line 288 "rtti_access.m"
}

#line 191 "rtti_access.m"
MR_Word MR_CALL 
mdbcomp__rtti_access__encode_len_string_func_1_f_0(
#line 191 "rtti_access.m"
  MR_String mdbcomp__rtti_access__String_3)
#line 191 "rtti_access.m"
{
#line 893 "rtti_access.m"
  {
#line 893 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 893 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Bytes_4;

#line 893 "rtti_access.m"
    {
#line 893 "rtti_access.m"
      mdbcomp__rtti_access__encode_len_string_2_p_0(mdbcomp__rtti_access__String_3, &mdbcomp__rtti_access__Bytes_4);
    }
#line 893 "rtti_access.m"
    return mdbcomp__rtti_access__Bytes_4;
#line 893 "rtti_access.m"
  }
#line 191 "rtti_access.m"
}

#line 889 "rtti_access.m"
static MR_Box MR_CALL 
mdbcomp__rtti_access__encode_len_string_2_p_0_1(
#line 889 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__closure_arg,
#line 889 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__wrapper_arg_1)
#line 889 "rtti_access.m"
{
#line 889 "rtti_access.m"
  {
#line 889 "rtti_access.m"
    MR_Box mdbcomp__rtti_access__wrapper_arg_2;
#line 889 "rtti_access.m"
    MR_Box mdbcomp__rtti_access__closure = mdbcomp__rtti_access__closure_arg;
#line 889 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__conv0_HeadVar__2_2;

#line 889 "rtti_access.m"
    {
#line 889 "rtti_access.m"
      mdbcomp__rtti_access__conv0_HeadVar__2_2 = mercury__char__to_int_1_f_0(((MR_Char) (MR_Word) mdbcomp__rtti_access__wrapper_arg_1));
    }
#line 889 "rtti_access.m"
    mdbcomp__rtti_access__wrapper_arg_2 = ((MR_Box) (mdbcomp__rtti_access__conv0_HeadVar__2_2));
#line 889 "rtti_access.m"
    return mdbcomp__rtti_access__wrapper_arg_2;
#line 889 "rtti_access.m"
  }
#line 889 "rtti_access.m"
}

#line 190 "rtti_access.m"
void MR_CALL 
mdbcomp__rtti_access__encode_len_string_2_p_0(
#line 190 "rtti_access.m"
  MR_String mdbcomp__rtti_access__String_3,
#line 190 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__Bytes_4)
#line 190 "rtti_access.m"
{
#line 885 "rtti_access.m"
  {
#line 885 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 885 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__TypeCtorInfo_11_11;
#line 885 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Length_5;
#line 885 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__LengthBytes_6;
#line 885 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Chars_7;
#line 885 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__CharBytes_8;
#line 878 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__BytesPrime_16;

#line 886 "rtti_access.m"
    {
#line 886 "rtti_access.m"
      mercury__string__length_2_p_0(mdbcomp__rtti_access__String_3, &mdbcomp__rtti_access__Length_5);
    }
#line 876 "rtti_access.m"
    {
#line 876 "rtti_access.m"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access__encode_num_2_p_0(mdbcomp__rtti_access__Length_5, &mdbcomp__rtti_access__BytesPrime_16);
    }
#line 878 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 877 "rtti_access.m"
      mdbcomp__rtti_access__LengthBytes_6 = mdbcomp__rtti_access__BytesPrime_16;
#line 878 "rtti_access.m"
    else
#line 879 "rtti_access.m"
      {
#line 879 "rtti_access.m"
        {
#line 879 "rtti_access.m"
          mercury__require__unexpected_3_p_0((MR_String) "mdbcomp.rtti_access", (MR_String) "predicate \140mdbcomp.rtti_access.encode_num_det\'/2", (MR_String) "encode_num failed");
#line 879 "rtti_access.m"
          return;
        }
#line 879 "rtti_access.m"
      }
#line 888 "rtti_access.m"
    {
#line 888 "rtti_access.m"
      mercury__string__to_char_list_2_p_0(mdbcomp__rtti_access__String_3, &mdbcomp__rtti_access__Chars_7);
    }
#line 2841 "mdbcomp.rtti_access.c"
    mdbcomp__rtti_access__TypeCtorInfo_11_11 = (MR_Word) &mercury__builtin__builtin__type_ctor_info_int_0;
#line 889 "rtti_access.m"
    {
#line 889 "rtti_access.m"
      mdbcomp__rtti_access__CharBytes_8 = mercury__list__map_2_f_0((MR_Word) &mercury__builtin__builtin__type_ctor_info_character_0, mdbcomp__rtti_access__TypeCtorInfo_11_11, (MR_Word) &mdbcomp__rtti_access_scalar_common_2[0], mdbcomp__rtti_access__Chars_7);
    }
#line 890 "rtti_access.m"
    {
#line 890 "rtti_access.m"
      *mdbcomp__rtti_access__Bytes_4 = mercury__list__f_43_43_2_f_0(mdbcomp__rtti_access__TypeCtorInfo_11_11, mdbcomp__rtti_access__LengthBytes_6, mdbcomp__rtti_access__CharBytes_8);
    }
#line 885 "rtti_access.m"
  }
#line 190 "rtti_access.m"
}

#line 188 "rtti_access.m"
MR_Word MR_CALL 
mdbcomp__rtti_access__encode_num_func_1_f_0(
#line 188 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Num_3)
#line 188 "rtti_access.m"
{
#line 878 "rtti_access.m"
  {
#line 878 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 878 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Bytes_4;
#line 878 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__BytesPrime_7;

#line 876 "rtti_access.m"
    {
#line 876 "rtti_access.m"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access__encode_num_2_p_0(mdbcomp__rtti_access__Num_3, &mdbcomp__rtti_access__BytesPrime_7);
    }
#line 878 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 877 "rtti_access.m"
      mdbcomp__rtti_access__Bytes_4 = mdbcomp__rtti_access__BytesPrime_7;
#line 878 "rtti_access.m"
    else
#line 879 "rtti_access.m"
      {
#line 879 "rtti_access.m"
        {
#line 879 "rtti_access.m"
          mercury__require__unexpected_3_p_0((MR_String) "mdbcomp.rtti_access", (MR_String) "predicate \140mdbcomp.rtti_access.encode_num_det\'/2", (MR_String) "encode_num failed");
        }
#line 879 "rtti_access.m"
      }
#line 878 "rtti_access.m"
    return mdbcomp__rtti_access__Bytes_4;
#line 878 "rtti_access.m"
  }
#line 188 "rtti_access.m"
}

#line 187 "rtti_access.m"
void MR_CALL 
mdbcomp__rtti_access__encode_num_det_2_p_0(
#line 187 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Num_3,
#line 187 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__Bytes_4)
#line 187 "rtti_access.m"
{
#line 878 "rtti_access.m"
  {
#line 878 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 878 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__BytesPrime_5;

#line 876 "rtti_access.m"
    {
#line 876 "rtti_access.m"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access__encode_num_2_p_0(mdbcomp__rtti_access__Num_3, &mdbcomp__rtti_access__BytesPrime_5);
    }
#line 878 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 877 "rtti_access.m"
      *mdbcomp__rtti_access__Bytes_4 = mdbcomp__rtti_access__BytesPrime_5;
#line 878 "rtti_access.m"
    else
#line 879 "rtti_access.m"
      {
#line 879 "rtti_access.m"
        {
#line 879 "rtti_access.m"
          mercury__require__unexpected_3_p_0((MR_String) "mdbcomp.rtti_access", (MR_String) "predicate \140mdbcomp.rtti_access.encode_num_det\'/2", (MR_String) "encode_num failed");
#line 879 "rtti_access.m"
          return;
        }
#line 879 "rtti_access.m"
      }
#line 878 "rtti_access.m"
  }
#line 187 "rtti_access.m"
}

#line 186 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access__encode_num_2_p_0(
#line 186 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Num_3,
#line 186 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__Bytes_4)
#line 186 "rtti_access.m"
{
#line 858 "rtti_access.m"
  {
#line 858 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__Num_3 >= (MR_Integer) 0);
#line 858 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__LastByte_5;
#line 858 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__NextNum_6;
#line 858 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_8_8;
#line 858 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_9_9;
#line 858 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__V_10_10;
#line 858 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__V_11_11;

#line 858 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 858 "rtti_access.m"
      {
#line 860 "rtti_access.m"
        mdbcomp__rtti_access__V_8_8 = (MR_Integer) 127;
#line 860 "rtti_access.m"
        mdbcomp__rtti_access__LastByte_5 = (mdbcomp__rtti_access__Num_3 & mdbcomp__rtti_access__V_8_8);
#line 861 "rtti_access.m"
        mdbcomp__rtti_access__V_9_9 = (MR_Integer) 128;
#line 861 "rtti_access.m"
        {
#line 861 "rtti_access.m"
          mdbcomp__rtti_access__NextNum_6 = mercury__int__f_slash_2_f_0(mdbcomp__rtti_access__Num_3, mdbcomp__rtti_access__V_9_9);
        }
#line 862 "rtti_access.m"
        mdbcomp__rtti_access__V_11_11 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 862 "rtti_access.m"
        {
#line 862 "rtti_access.m"
          mdbcomp__rtti_access__V_10_10 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), NULL, NULL));
#line 862 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__V_10_10, 0) = ((MR_Box) (mdbcomp__rtti_access__LastByte_5));
#line 862 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__V_10_10, 1) = ((MR_Box) (mdbcomp__rtti_access__V_11_11));
#line 862 "rtti_access.m"
        }
#line 862 "rtti_access.m"
        {
#line 862 "rtti_access.m"
          mdbcomp__rtti_access__encode_num_2_3_p_0(mdbcomp__rtti_access__NextNum_6, mdbcomp__rtti_access__V_10_10, mdbcomp__rtti_access__Bytes_4);
        }
#line 862 "rtti_access.m"
        mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 858 "rtti_access.m"
      }
#line 858 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 858 "rtti_access.m"
  }
#line 186 "rtti_access.m"
}

#line 184 "rtti_access.m"
MR_Word MR_CALL 
mdbcomp__rtti_access__encode_int32_func_1_f_0(
#line 184 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Int32_3)
#line 184 "rtti_access.m"
{
#line 851 "rtti_access.m"
  {
#line 851 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 851 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Bytes_4;
#line 851 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__BytesPrime_7;

#line 849 "rtti_access.m"
    {
#line 849 "rtti_access.m"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access__encode_int32_2_p_0(mdbcomp__rtti_access__Int32_3, &mdbcomp__rtti_access__BytesPrime_7);
    }
#line 851 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 850 "rtti_access.m"
      mdbcomp__rtti_access__Bytes_4 = mdbcomp__rtti_access__BytesPrime_7;
#line 851 "rtti_access.m"
    else
#line 852 "rtti_access.m"
      {
#line 852 "rtti_access.m"
        {
#line 852 "rtti_access.m"
          mercury__require__unexpected_3_p_0((MR_String) "mdbcomp.rtti_access", (MR_String) "predicate \140mdbcomp.rtti_access.encode_int32_det\'/2", (MR_String) "encode_int32 failed");
        }
#line 852 "rtti_access.m"
      }
#line 851 "rtti_access.m"
    return mdbcomp__rtti_access__Bytes_4;
#line 851 "rtti_access.m"
  }
#line 184 "rtti_access.m"
}

#line 183 "rtti_access.m"
void MR_CALL 
mdbcomp__rtti_access__encode_int32_det_2_p_0(
#line 183 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Int32_3,
#line 183 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__Bytes_4)
#line 183 "rtti_access.m"
{
#line 851 "rtti_access.m"
  {
#line 851 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 851 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__BytesPrime_5;

#line 849 "rtti_access.m"
    {
#line 849 "rtti_access.m"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access__encode_int32_2_p_0(mdbcomp__rtti_access__Int32_3, &mdbcomp__rtti_access__BytesPrime_5);
    }
#line 851 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 850 "rtti_access.m"
      *mdbcomp__rtti_access__Bytes_4 = mdbcomp__rtti_access__BytesPrime_5;
#line 851 "rtti_access.m"
    else
#line 852 "rtti_access.m"
      {
#line 852 "rtti_access.m"
        {
#line 852 "rtti_access.m"
          mercury__require__unexpected_3_p_0((MR_String) "mdbcomp.rtti_access", (MR_String) "predicate \140mdbcomp.rtti_access.encode_int32_det\'/2", (MR_String) "encode_int32 failed");
#line 852 "rtti_access.m"
          return;
        }
#line 852 "rtti_access.m"
      }
#line 851 "rtti_access.m"
  }
#line 183 "rtti_access.m"
}

#line 182 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access__encode_int32_2_p_0(
#line 182 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Int32_3,
#line 182 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__HeadVar__2_2)
#line 182 "rtti_access.m"
{
#line 838 "rtti_access.m"
  {
#line 838 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__Int32_3 >= (MR_Integer) 0);
#line 838 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Byte1_4;
#line 838 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Byte2_5;
#line 838 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Byte3_6;
#line 838 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Byte4_7;
#line 838 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Bytes123_8;
#line 838 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Bytes12_9;
#line 838 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__V_10_10;
#line 838 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__V_11_11;
#line 838 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__V_12_12;
#line 838 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_15_15;
#line 838 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_16_16;
#line 838 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_17_17;
#line 838 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_18_18;
#line 838 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_19_19;
#line 838 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_20_20;
#line 838 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_21_21;

#line 838 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 838 "rtti_access.m"
      {
#line 840 "rtti_access.m"
        mdbcomp__rtti_access__V_15_15 = (MR_Integer) 255;
#line 840 "rtti_access.m"
        mdbcomp__rtti_access__Byte4_7 = (mdbcomp__rtti_access__Int32_3 & mdbcomp__rtti_access__V_15_15);
#line 841 "rtti_access.m"
        mdbcomp__rtti_access__V_16_16 = (MR_Integer) 256;
#line 838 "rtti_access.m"
        {
#line 838 "rtti_access.m"
          mdbcomp__rtti_access__V_12_12 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), NULL, NULL));
#line 838 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__V_12_12, 0) = ((MR_Box) (mdbcomp__rtti_access__Byte4_7));
#line 838 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__V_12_12, 1) = ((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))));
#line 838 "rtti_access.m"
        }
#line 841 "rtti_access.m"
        {
#line 841 "rtti_access.m"
          mdbcomp__rtti_access__Bytes123_8 = mercury__int__f_slash_2_f_0(mdbcomp__rtti_access__Int32_3, mdbcomp__rtti_access__V_16_16);
        }
#line 842 "rtti_access.m"
        mdbcomp__rtti_access__V_17_17 = (MR_Integer) 255;
#line 842 "rtti_access.m"
        mdbcomp__rtti_access__Byte3_6 = (mdbcomp__rtti_access__Bytes123_8 & mdbcomp__rtti_access__V_17_17);
#line 843 "rtti_access.m"
        mdbcomp__rtti_access__V_18_18 = (MR_Integer) 256;
#line 838 "rtti_access.m"
        {
#line 838 "rtti_access.m"
          mdbcomp__rtti_access__V_11_11 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), NULL, NULL));
#line 838 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__V_11_11, 0) = ((MR_Box) (mdbcomp__rtti_access__Byte3_6));
#line 838 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__V_11_11, 1) = ((MR_Box) (mdbcomp__rtti_access__V_12_12));
#line 838 "rtti_access.m"
        }
#line 843 "rtti_access.m"
        {
#line 843 "rtti_access.m"
          mdbcomp__rtti_access__Bytes12_9 = mercury__int__f_slash_2_f_0(mdbcomp__rtti_access__Bytes123_8, mdbcomp__rtti_access__V_18_18);
        }
#line 844 "rtti_access.m"
        mdbcomp__rtti_access__V_19_19 = (MR_Integer) 255;
#line 844 "rtti_access.m"
        mdbcomp__rtti_access__Byte2_5 = (mdbcomp__rtti_access__Bytes12_9 & mdbcomp__rtti_access__V_19_19);
#line 845 "rtti_access.m"
        mdbcomp__rtti_access__V_20_20 = (MR_Integer) 256;
#line 838 "rtti_access.m"
        {
#line 838 "rtti_access.m"
          mdbcomp__rtti_access__V_10_10 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), NULL, NULL));
#line 838 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__V_10_10, 0) = ((MR_Box) (mdbcomp__rtti_access__Byte2_5));
#line 838 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__V_10_10, 1) = ((MR_Box) (mdbcomp__rtti_access__V_11_11));
#line 838 "rtti_access.m"
        }
#line 845 "rtti_access.m"
        {
#line 845 "rtti_access.m"
          mdbcomp__rtti_access__Byte1_4 = mercury__int__f_slash_2_f_0(mdbcomp__rtti_access__Bytes12_9, mdbcomp__rtti_access__V_20_20);
        }
#line 846 "rtti_access.m"
        mdbcomp__rtti_access__V_21_21 = (MR_Integer) 128;
#line 846 "rtti_access.m"
        mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__Byte1_4 < mdbcomp__rtti_access__V_21_21);
#line 838 "rtti_access.m"
        if (mdbcomp__rtti_access__succeeded)
#line 838 "rtti_access.m"
          {
#line 838 "rtti_access.m"
            {
#line 838 "rtti_access.m"
              MR_Word base;
#line 838 "rtti_access.m"
              base = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), NULL, NULL));
#line 838 "rtti_access.m"
              *mdbcomp__rtti_access__HeadVar__2_2 = base;
#line 838 "rtti_access.m"
              MR_hl_field(MR_mktag(1), base, 0) = ((MR_Box) (mdbcomp__rtti_access__Byte1_4));
#line 838 "rtti_access.m"
              MR_hl_field(MR_mktag(1), base, 1) = ((MR_Box) (mdbcomp__rtti_access__V_10_10));
#line 838 "rtti_access.m"
            }
#line 838 "rtti_access.m"
            mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 838 "rtti_access.m"
          }
#line 838 "rtti_access.m"
      }
#line 838 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 838 "rtti_access.m"
  }
#line 182 "rtti_access.m"
}

#line 180 "rtti_access.m"
MR_Word MR_CALL 
mdbcomp__rtti_access__encode_short_func_1_f_0(
#line 180 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Short_3)
#line 180 "rtti_access.m"
{
#line 831 "rtti_access.m"
  {
#line 831 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 831 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Bytes_4;
#line 831 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__BytesPrime_7;

#line 829 "rtti_access.m"
    {
#line 829 "rtti_access.m"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access__encode_short_2_p_0(mdbcomp__rtti_access__Short_3, &mdbcomp__rtti_access__BytesPrime_7);
    }
#line 831 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 830 "rtti_access.m"
      mdbcomp__rtti_access__Bytes_4 = mdbcomp__rtti_access__BytesPrime_7;
#line 831 "rtti_access.m"
    else
#line 832 "rtti_access.m"
      {
#line 832 "rtti_access.m"
        {
#line 832 "rtti_access.m"
          mercury__require__unexpected_3_p_0((MR_String) "mdbcomp.rtti_access", (MR_String) "predicate \140mdbcomp.rtti_access.encode_short_det\'/2", (MR_String) "encode_short failed");
        }
#line 832 "rtti_access.m"
      }
#line 831 "rtti_access.m"
    return mdbcomp__rtti_access__Bytes_4;
#line 831 "rtti_access.m"
  }
#line 180 "rtti_access.m"
}

#line 179 "rtti_access.m"
void MR_CALL 
mdbcomp__rtti_access__encode_short_det_2_p_0(
#line 179 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Short_3,
#line 179 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__Bytes_4)
#line 179 "rtti_access.m"
{
#line 831 "rtti_access.m"
  {
#line 831 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 831 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__BytesPrime_5;

#line 829 "rtti_access.m"
    {
#line 829 "rtti_access.m"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access__encode_short_2_p_0(mdbcomp__rtti_access__Short_3, &mdbcomp__rtti_access__BytesPrime_5);
    }
#line 831 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 830 "rtti_access.m"
      *mdbcomp__rtti_access__Bytes_4 = mdbcomp__rtti_access__BytesPrime_5;
#line 831 "rtti_access.m"
    else
#line 832 "rtti_access.m"
      {
#line 832 "rtti_access.m"
        {
#line 832 "rtti_access.m"
          mercury__require__unexpected_3_p_0((MR_String) "mdbcomp.rtti_access", (MR_String) "predicate \140mdbcomp.rtti_access.encode_short_det\'/2", (MR_String) "encode_short failed");
#line 832 "rtti_access.m"
          return;
        }
#line 832 "rtti_access.m"
      }
#line 831 "rtti_access.m"
  }
#line 179 "rtti_access.m"
}

#line 178 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access__encode_short_2_p_0(
#line 178 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Short_3,
#line 178 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__HeadVar__2_2)
#line 178 "rtti_access.m"
{
#line 822 "rtti_access.m"
  {
#line 822 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__Short_3 >= (MR_Integer) 0);
#line 822 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Byte1_4;
#line 822 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Byte2_5;
#line 822 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__V_6_6;
#line 822 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_9_9;
#line 822 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_10_10;
#line 822 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_11_11;

#line 822 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 822 "rtti_access.m"
      {
#line 824 "rtti_access.m"
        mdbcomp__rtti_access__V_9_9 = (MR_Integer) 255;
#line 824 "rtti_access.m"
        mdbcomp__rtti_access__Byte2_5 = (mdbcomp__rtti_access__Short_3 & mdbcomp__rtti_access__V_9_9);
#line 825 "rtti_access.m"
        mdbcomp__rtti_access__V_10_10 = (MR_Integer) 256;
#line 822 "rtti_access.m"
        {
#line 822 "rtti_access.m"
          mdbcomp__rtti_access__V_6_6 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), NULL, NULL));
#line 822 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__V_6_6, 0) = ((MR_Box) (mdbcomp__rtti_access__Byte2_5));
#line 822 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__V_6_6, 1) = ((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))));
#line 822 "rtti_access.m"
        }
#line 825 "rtti_access.m"
        {
#line 825 "rtti_access.m"
          mdbcomp__rtti_access__Byte1_4 = mercury__int__f_slash_2_f_0(mdbcomp__rtti_access__Short_3, mdbcomp__rtti_access__V_10_10);
        }
#line 826 "rtti_access.m"
        mdbcomp__rtti_access__V_11_11 = (MR_Integer) 128;
#line 826 "rtti_access.m"
        mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__Byte1_4 < mdbcomp__rtti_access__V_11_11);
#line 822 "rtti_access.m"
        if (mdbcomp__rtti_access__succeeded)
#line 822 "rtti_access.m"
          {
#line 822 "rtti_access.m"
            {
#line 822 "rtti_access.m"
              MR_Word base;
#line 822 "rtti_access.m"
              base = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), NULL, NULL));
#line 822 "rtti_access.m"
              *mdbcomp__rtti_access__HeadVar__2_2 = base;
#line 822 "rtti_access.m"
              MR_hl_field(MR_mktag(1), base, 0) = ((MR_Box) (mdbcomp__rtti_access__Byte1_4));
#line 822 "rtti_access.m"
              MR_hl_field(MR_mktag(1), base, 1) = ((MR_Box) (mdbcomp__rtti_access__V_6_6));
#line 822 "rtti_access.m"
            }
#line 822 "rtti_access.m"
            mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 822 "rtti_access.m"
          }
#line 822 "rtti_access.m"
      }
#line 822 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 822 "rtti_access.m"
  }
#line 178 "rtti_access.m"
}

#line 176 "rtti_access.m"
MR_Word MR_CALL 
mdbcomp__rtti_access__encode_byte_func_1_f_0(
#line 176 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Byte_3)
#line 176 "rtti_access.m"
{
#line 820 "rtti_access.m"
  {
#line 820 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 820 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Bytes_4;

#line 820 "rtti_access.m"
    {
#line 820 "rtti_access.m"
      mdbcomp__rtti_access__encode_byte_det_2_p_0(mdbcomp__rtti_access__Byte_3, &mdbcomp__rtti_access__Bytes_4);
    }
#line 820 "rtti_access.m"
    return mdbcomp__rtti_access__Bytes_4;
#line 820 "rtti_access.m"
  }
#line 176 "rtti_access.m"
}

#line 175 "rtti_access.m"
void MR_CALL 
mdbcomp__rtti_access__encode_byte_det_2_p_0(
#line 175 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Byte_3,
#line 175 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__Bytes_4)
#line 175 "rtti_access.m"
{
#line 815 "rtti_access.m"
  {
#line 815 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__Byte_3 >= (MR_Integer) 0);
#line 815 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__BytesPrime_5;
#line 808 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_12_12;

#line 808 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 808 "rtti_access.m"
      {
#line 810 "rtti_access.m"
        mdbcomp__rtti_access__V_12_12 = (MR_Integer) 128;
#line 810 "rtti_access.m"
        mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__Byte_3 < mdbcomp__rtti_access__V_12_12);
#line 808 "rtti_access.m"
        if (mdbcomp__rtti_access__succeeded)
#line 808 "rtti_access.m"
          {
#line 808 "rtti_access.m"
            {
#line 808 "rtti_access.m"
              mdbcomp__rtti_access__BytesPrime_5 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), NULL, NULL));
#line 808 "rtti_access.m"
              MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__BytesPrime_5, 0) = ((MR_Box) (mdbcomp__rtti_access__Byte_3));
#line 808 "rtti_access.m"
              MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__BytesPrime_5, 1) = ((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))));
#line 808 "rtti_access.m"
            }
#line 808 "rtti_access.m"
            mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 808 "rtti_access.m"
          }
#line 808 "rtti_access.m"
      }
#line 815 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 814 "rtti_access.m"
      *mdbcomp__rtti_access__Bytes_4 = mdbcomp__rtti_access__BytesPrime_5;
#line 815 "rtti_access.m"
    else
#line 816 "rtti_access.m"
      {
#line 816 "rtti_access.m"
        {
#line 816 "rtti_access.m"
          mercury__require__unexpected_3_p_0((MR_String) "mdbcomp.rtti_access", (MR_String) "predicate \140mdbcomp.rtti_access.encode_byte_det\'/2", (MR_String) "encode_byte failed");
#line 816 "rtti_access.m"
          return;
        }
#line 816 "rtti_access.m"
      }
#line 815 "rtti_access.m"
  }
#line 175 "rtti_access.m"
}

#line 174 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access__encode_byte_2_p_0(
#line 174 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__Byte_3,
#line 174 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__HeadVar__2_2)
#line 174 "rtti_access.m"
{
#line 808 "rtti_access.m"
  {
#line 808 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__Byte_3 >= (MR_Integer) 0);
#line 808 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_6_6;

#line 808 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 808 "rtti_access.m"
      {
#line 810 "rtti_access.m"
        mdbcomp__rtti_access__V_6_6 = (MR_Integer) 128;
#line 810 "rtti_access.m"
        mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__Byte_3 < mdbcomp__rtti_access__V_6_6);
#line 808 "rtti_access.m"
        if (mdbcomp__rtti_access__succeeded)
#line 808 "rtti_access.m"
          {
#line 808 "rtti_access.m"
            {
#line 808 "rtti_access.m"
              MR_Word base;
#line 808 "rtti_access.m"
              base = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), NULL, NULL));
#line 808 "rtti_access.m"
              *mdbcomp__rtti_access__HeadVar__2_2 = base;
#line 808 "rtti_access.m"
              MR_hl_field(MR_mktag(1), base, 0) = ((MR_Box) (mdbcomp__rtti_access__Byte_3));
#line 808 "rtti_access.m"
              MR_hl_field(MR_mktag(1), base, 1) = ((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))));
#line 808 "rtti_access.m"
            }
#line 808 "rtti_access.m"
            mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 808 "rtti_access.m"
          }
#line 808 "rtti_access.m"
      }
#line 808 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 808 "rtti_access.m"
  }
#line 174 "rtti_access.m"
}

#line 169 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access__read_string_table_4_p_0(
#line 169 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__ByteCode_5,
#line 169 "rtti_access.m"
  MR_Word * mdbcomp__rtti_access__StringTable_6,
#line 169 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_12,
#line 169 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__STATE_VARIABLE_Pos_13)
#line 169 "rtti_access.m"
{
#line 777 "rtti_access.m"
  {
#line 777 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 777 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Size_8;
#line 777 "rtti_access.m"
    MR_Box mdbcomp__rtti_access__Bytes_9;
#line 777 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__NumBytes_10;
#line 777 "rtti_access.m"
    MR_Box mdbcomp__rtti_access__StringTableChars_11;
#line 777 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_14_14;
#line 777 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_15_15;
#line 788 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__TypeCtorInfo_17_25;
#line 788 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__TypeCtorInfo_17_26;

#line 724 "rtti_access.m"
    {
#line 724 "rtti_access.m"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access__read_num_2_5_p_0(mdbcomp__rtti_access__ByteCode_5, (MR_Integer) 0, &mdbcomp__rtti_access__Size_8, mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_12, &mdbcomp__rtti_access__STATE_VARIABLE_Pos_14_14);
    }
#line 777 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 777 "rtti_access.m"
      {
#line 779 "rtti_access.m"
        mdbcomp__rtti_access__Bytes_9 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_5, (MR_Integer) 0)));
#line 779 "rtti_access.m"
        mdbcomp__rtti_access__NumBytes_10 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_5, (MR_Integer) 1)));
#line 780 "rtti_access.m"
        mdbcomp__rtti_access__V_15_15 = (mdbcomp__rtti_access__STATE_VARIABLE_Pos_14_14 + mdbcomp__rtti_access__Size_8);
#line 780 "rtti_access.m"
        mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__V_15_15 <= mdbcomp__rtti_access__NumBytes_10);
#line 777 "rtti_access.m"
        if (mdbcomp__rtti_access__succeeded)
#line 777 "rtti_access.m"
          {
#line 792 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__read_string_table_4_p_0

	const MR_uint_least8_t * Bytes;
	MR_Word Offset;
	MR_Word Size;
	MR_ConstString StringTableChars;

	Bytes = (const MR_uint_least8_t *) mdbcomp__rtti_access__Bytes_9 ;
	Offset = (MR_Word) ((MR_Box) (mdbcomp__rtti_access__STATE_VARIABLE_Pos_14_14)) ;
	Size = (MR_Word) ((MR_Box) (mdbcomp__rtti_access__Size_8)) ;
		{
#line 792 "rtti_access.m"

    char        *buf;
    char        *table;
    MR_Unsigned i;

    MR_allocate_aligned_string_msg(buf, Size, MR_ALLOC_ID);
    table = ((char *) Bytes) + Offset;
    for (i = 0; i < Size; i++) {
        buf[i] = table[i];
    }

    StringTableChars = (MR_ConstString) buf;

#line 3650 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__StringTableChars_11  = (MR_Box) StringTableChars;
#line 792 "rtti_access.m"
}
#line 782 "rtti_access.m"
            *mdbcomp__rtti_access__STATE_VARIABLE_Pos_13 = (mdbcomp__rtti_access__STATE_VARIABLE_Pos_14_14 + mdbcomp__rtti_access__Size_8);
#line 783 "rtti_access.m"
            {
#line 783 "rtti_access.m"
              MR_Word base;
#line 783 "rtti_access.m"
              base = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), NULL, NULL);
#line 783 "rtti_access.m"
              *mdbcomp__rtti_access__StringTable_6 = base;
#line 783 "rtti_access.m"
              MR_hl_field(MR_mktag(0), base, 0) = ((MR_Box) (mdbcomp__rtti_access__StringTableChars_11));
#line 783 "rtti_access.m"
              MR_hl_field(MR_mktag(0), base, 1) = ((MR_Box) (mdbcomp__rtti_access__Size_8));
#line 783 "rtti_access.m"
            }
#line 783 "rtti_access.m"
            mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 777 "rtti_access.m"
          }
#line 777 "rtti_access.m"
      }
#line 777 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 777 "rtti_access.m"
  }
#line 169 "rtti_access.m"
}

#line 160 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access__read_len_string_4_p_0(
#line 160 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__ByteCode_5,
#line 160 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__String_6,
#line 160 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_10,
#line 160 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__STATE_VARIABLE_Pos_11)
#line 160 "rtti_access.m"
{
#line 759 "rtti_access.m"
  {
#line 759 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 759 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Length_8;
#line 759 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__RevChars_9;
#line 759 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_12_12;
#line 759 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__V_13_13;

#line 724 "rtti_access.m"
    {
#line 724 "rtti_access.m"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access__read_num_2_5_p_0(mdbcomp__rtti_access__ByteCode_5, (MR_Integer) 0, &mdbcomp__rtti_access__Length_8, mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_10, &mdbcomp__rtti_access__STATE_VARIABLE_Pos_12_12);
    }
#line 759 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 759 "rtti_access.m"
      {
#line 761 "rtti_access.m"
        mdbcomp__rtti_access__V_13_13 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 761 "rtti_access.m"
        {
#line 761 "rtti_access.m"
          mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access__read_len_string_2_6_p_0(mdbcomp__rtti_access__ByteCode_5, mdbcomp__rtti_access__Length_8, mdbcomp__rtti_access__V_13_13, &mdbcomp__rtti_access__RevChars_9, mdbcomp__rtti_access__STATE_VARIABLE_Pos_12_12, mdbcomp__rtti_access__STATE_VARIABLE_Pos_11);
        }
#line 759 "rtti_access.m"
        if (mdbcomp__rtti_access__succeeded)
#line 759 "rtti_access.m"
          {
#line 762 "rtti_access.m"
            {
#line 762 "rtti_access.m"
              mercury__string__from_rev_char_list_2_p_0(mdbcomp__rtti_access__RevChars_9, mdbcomp__rtti_access__String_6);
            }
#line 762 "rtti_access.m"
            mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 759 "rtti_access.m"
          }
#line 759 "rtti_access.m"
      }
#line 759 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 759 "rtti_access.m"
  }
#line 160 "rtti_access.m"
}

#line 152 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access__read_line_4_p_0(
#line 152 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__ByteCode_5,
#line 152 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__Line_6,
#line 152 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_9,
#line 152 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__STATE_VARIABLE_Pos_10)
#line 152 "rtti_access.m"
{
#line 742 "rtti_access.m"
  {
#line 742 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 742 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__RevChars_8;

#line 743 "rtti_access.m"
    {
#line 743 "rtti_access.m"
      mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access__read_line_2_5_p_0(mdbcomp__rtti_access__ByteCode_5, (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)), &mdbcomp__rtti_access__RevChars_8, mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_9, mdbcomp__rtti_access__STATE_VARIABLE_Pos_10);
    }
#line 742 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 742 "rtti_access.m"
      {
#line 744 "rtti_access.m"
        {
#line 744 "rtti_access.m"
          mercury__string__from_rev_char_list_2_p_0(mdbcomp__rtti_access__RevChars_8, mdbcomp__rtti_access__Line_6);
        }
#line 744 "rtti_access.m"
        mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 742 "rtti_access.m"
      }
#line 742 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 742 "rtti_access.m"
  }
#line 152 "rtti_access.m"
}

#line 145 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access__read_string_via_offset_5_p_0(
#line 145 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__ByteCode_6,
#line 145 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__StringTable_7,
#line 145 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__String_8,
#line 145 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_11,
#line 145 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__STATE_VARIABLE_Pos_12)
#line 145 "rtti_access.m"
{
#line 738 "rtti_access.m"
  {
#line 738 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 738 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Offset_10;
#line 738 "rtti_access.m"
    MR_Box mdbcomp__rtti_access__Bytes_19 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_6, (MR_Integer) 0)));
#line 738 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Size_20 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_6, (MR_Integer) 1)));
#line 738 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_21_21 = (mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_11 + (MR_Integer) 4);
#line 738 "rtti_access.m"
    MR_Box mdbcomp__rtti_access__StringTableChars_27;
#line 738 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Size_28;

#line 709 "rtti_access.m"
    mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__V_21_21 <= mdbcomp__rtti_access__Size_20);
#line 738 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 738 "rtti_access.m"
      {
#line 717 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__read_string_via_offset_5_p_0

	const MR_uint_least8_t * ByteCode;
	MR_Integer Value;
	MR_Integer Pos0;
	MR_Integer Pos;

	ByteCode = (const MR_uint_least8_t *) mdbcomp__rtti_access__Bytes_19 ;
	Pos0 =  mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_11 ;
		{
#line 717 "rtti_access.m"

    Value = (ByteCode[Pos0] << 24) + (ByteCode[Pos0+1] << 16) +
        (ByteCode[Pos0+2] << 8) + ByteCode[Pos0+3];
    Pos = Pos0 + 4;

#line 3851 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__Offset_10  = Value;
	 *mdbcomp__rtti_access__STATE_VARIABLE_Pos_12  = Pos;
#line 717 "rtti_access.m"
}
#line 653 "rtti_access.m"
        mdbcomp__rtti_access__StringTableChars_27 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__StringTable_7, (MR_Integer) 0)));
#line 653 "rtti_access.m"
        mdbcomp__rtti_access__Size_28 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__StringTable_7, (MR_Integer) 1)));
#line 662 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__read_string_via_offset_5_p_0

	MR_ConstString StringTableChars;
	MR_Integer StringTableSize;
	MR_Integer NameCode;
	MR_String Str;

	StringTableChars = (MR_ConstString) mdbcomp__rtti_access__StringTableChars_27 ;
	StringTableSize =  mdbcomp__rtti_access__Size_28 ;
	NameCode =  mdbcomp__rtti_access__Offset_10 ;
		{
#line 662 "rtti_access.m"

    MR_ConstString  str0;
    int             should_copy;

    str0 = MR_name_in_string_table(StringTableChars, StringTableSize,
        (MR_uint_least32_t)NameCode, &should_copy);
    if (should_copy) {
        MR_make_aligned_string(Str, str0);
    } else {
        MR_make_aligned_string_copy(Str, str0);
    }

#line 3889 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 *mdbcomp__rtti_access__String_8  = Str;
#line 662 "rtti_access.m"
}
#line 658 "rtti_access.m"
        mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 738 "rtti_access.m"
      }
#line 738 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 738 "rtti_access.m"
  }
#line 145 "rtti_access.m"
}

#line 138 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access__read_num_4_p_0(
#line 138 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__ByteCode_5,
#line 138 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Num_6,
#line 138 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_8,
#line 138 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__STATE_VARIABLE_Pos_9)
#line 138 "rtti_access.m"
{
#line 723 "rtti_access.m"
  {
#line 723 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 724 "rtti_access.m"
    {
#line 724 "rtti_access.m"
      return mdbcomp__rtti_access__succeeded = mdbcomp__rtti_access__read_num_2_5_p_0(mdbcomp__rtti_access__ByteCode_5, (MR_Integer) 0, mdbcomp__rtti_access__Num_6, mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_8, mdbcomp__rtti_access__STATE_VARIABLE_Pos_9);
    }
#line 723 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 723 "rtti_access.m"
  }
#line 138 "rtti_access.m"
}

#line 131 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access__read_int32_4_p_0(
#line 131 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__ByteCode_5,
#line 131 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Value_6,
#line 131 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_10,
#line 131 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__STATE_VARIABLE_Pos_11)
#line 131 "rtti_access.m"
{
#line 707 "rtti_access.m"
  {
#line 707 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 707 "rtti_access.m"
    MR_Box mdbcomp__rtti_access__Bytes_8 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_5, (MR_Integer) 0)));
#line 707 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Size_9 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_5, (MR_Integer) 1)));
#line 707 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_12_12 = (mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_10 + (MR_Integer) 4);

#line 709 "rtti_access.m"
    mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__V_12_12 <= mdbcomp__rtti_access__Size_9);
#line 707 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 707 "rtti_access.m"
      {
#line 717 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__read_int32_4_p_0

	const MR_uint_least8_t * ByteCode;
	MR_Integer Value;
	MR_Integer Pos0;
	MR_Integer Pos;

	ByteCode = (const MR_uint_least8_t *) mdbcomp__rtti_access__Bytes_8 ;
	Pos0 =  mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_10 ;
		{
#line 717 "rtti_access.m"

    Value = (ByteCode[Pos0] << 24) + (ByteCode[Pos0+1] << 16) +
        (ByteCode[Pos0+2] << 8) + ByteCode[Pos0+3];
    Pos = Pos0 + 4;

#line 3985 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 *mdbcomp__rtti_access__Value_6  = Value;
	 *mdbcomp__rtti_access__STATE_VARIABLE_Pos_11  = Pos;
#line 717 "rtti_access.m"
}
#line 714 "rtti_access.m"
        mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 707 "rtti_access.m"
      }
#line 707 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 707 "rtti_access.m"
  }
#line 131 "rtti_access.m"
}

#line 125 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access__read_short_4_p_0(
#line 125 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__ByteCode_5,
#line 125 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Value_6,
#line 125 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_10,
#line 125 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__STATE_VARIABLE_Pos_11)
#line 125 "rtti_access.m"
{
#line 692 "rtti_access.m"
  {
#line 692 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 692 "rtti_access.m"
    MR_Box mdbcomp__rtti_access__Bytes_8 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_5, (MR_Integer) 0)));
#line 692 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Size_9 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_5, (MR_Integer) 1)));
#line 692 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_12_12 = (mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_10 + (MR_Integer) 2);

#line 694 "rtti_access.m"
    mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__V_12_12 <= mdbcomp__rtti_access__Size_9);
#line 692 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 692 "rtti_access.m"
      {
#line 702 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__read_short_4_p_0

	const MR_uint_least8_t * ByteCode;
	MR_Integer Value;
	MR_Integer Pos0;
	MR_Integer Pos;

	ByteCode = (const MR_uint_least8_t *) mdbcomp__rtti_access__Bytes_8 ;
	Pos0 =  mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_10 ;
		{
#line 702 "rtti_access.m"

    Value = (ByteCode[Pos0] << 8) + ByteCode[Pos0+1];
    Pos = Pos0 + 2;

#line 4051 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 *mdbcomp__rtti_access__Value_6  = Value;
	 *mdbcomp__rtti_access__STATE_VARIABLE_Pos_11  = Pos;
#line 702 "rtti_access.m"
}
#line 699 "rtti_access.m"
        mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 692 "rtti_access.m"
      }
#line 692 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 692 "rtti_access.m"
  }
#line 125 "rtti_access.m"
}

#line 119 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access__read_byte_4_p_0(
#line 119 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__ByteCode_5,
#line 119 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__Value_6,
#line 119 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_10,
#line 119 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__STATE_VARIABLE_Pos_11)
#line 119 "rtti_access.m"
{
#line 677 "rtti_access.m"
  {
#line 677 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 677 "rtti_access.m"
    MR_Box mdbcomp__rtti_access__Bytes_8 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_5, (MR_Integer) 0)));
#line 677 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Size_9 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ByteCode_5, (MR_Integer) 1)));
#line 677 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__V_12_12 = (mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_10 + (MR_Integer) 1);

#line 679 "rtti_access.m"
    mdbcomp__rtti_access__succeeded = (mdbcomp__rtti_access__V_12_12 <= mdbcomp__rtti_access__Size_9);
#line 677 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 677 "rtti_access.m"
      {
#line 687 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__read_byte_4_p_0

	const MR_uint_least8_t * ByteCode;
	MR_Integer Value;
	MR_Integer Pos0;
	MR_Integer Pos;

	ByteCode = (const MR_uint_least8_t *) mdbcomp__rtti_access__Bytes_8 ;
	Pos0 =  mdbcomp__rtti_access__STATE_VARIABLE_Pos_0_10 ;
		{
#line 687 "rtti_access.m"

    Value = ByteCode[Pos0];
    Pos = Pos0 + 1;

#line 4117 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 *mdbcomp__rtti_access__Value_6  = Value;
	 *mdbcomp__rtti_access__STATE_VARIABLE_Pos_11  = Pos;
#line 687 "rtti_access.m"
}
#line 684 "rtti_access.m"
        mdbcomp__rtti_access__succeeded = MR_TRUE;
#line 677 "rtti_access.m"
      }
#line 677 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 677 "rtti_access.m"
  }
#line 119 "rtti_access.m"
}

#line 95 "rtti_access.m"
MR_String MR_CALL 
mdbcomp__rtti_access__lookup_string_table_2_f_0(
#line 95 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__StringTable_4,
#line 95 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__NameCode_5)
#line 95 "rtti_access.m"
{
#line 652 "rtti_access.m"
  {
#line 652 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 652 "rtti_access.m"
    MR_String mdbcomp__rtti_access__Str_6;
#line 652 "rtti_access.m"
    MR_Box mdbcomp__rtti_access__StringTableChars_7 = ((MR_Box) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__StringTable_4, (MR_Integer) 0)));
#line 652 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Size_8 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__StringTable_4, (MR_Integer) 1)));

#line 662 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__lookup_string_table_2_f_0

	MR_ConstString StringTableChars;
	MR_Integer StringTableSize;
	MR_Integer NameCode;
	MR_String Str;

	StringTableChars = (MR_ConstString) mdbcomp__rtti_access__StringTableChars_7 ;
	StringTableSize =  mdbcomp__rtti_access__Size_8 ;
	NameCode =  mdbcomp__rtti_access__NameCode_5 ;
		{
#line 662 "rtti_access.m"

    MR_ConstString  str0;
    int             should_copy;

    str0 = MR_name_in_string_table(StringTableChars, StringTableSize,
        (MR_uint_least32_t)NameCode, &should_copy);
    if (should_copy) {
        MR_make_aligned_string(Str, str0);
    } else {
        MR_make_aligned_string_copy(Str, str0);
    }

#line 4182 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__Str_6  = Str;
#line 662 "rtti_access.m"
}
#line 652 "rtti_access.m"
    return mdbcomp__rtti_access__Str_6;
#line 652 "rtti_access.m"
  }
#line 95 "rtti_access.m"
}

#line 93 "rtti_access.m"
MR_Word MR_CALL 
mdbcomp__rtti_access__module_string_table_1_f_0(
#line 93 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__ModuleLayout_3)
#line 93 "rtti_access.m"
{
#line 636 "rtti_access.m"
  {
#line 636 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 636 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__StringTable_4;
#line 636 "rtti_access.m"
    MR_Box mdbcomp__rtti_access__StringTableChars_5;
#line 636 "rtti_access.m"
    MR_Integer mdbcomp__rtti_access__Size_6;

#line 647 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__module_string_table_1_f_0

	const MR_ModuleLayout * ModuleLayout;
	MR_ConstString StringTableChars;
	MR_Integer Size;

	ModuleLayout = (const MR_ModuleLayout *) mdbcomp__rtti_access__ModuleLayout_3 ;
		{
#line 647 "rtti_access.m"

    StringTableChars = ModuleLayout->MR_ml_string_table;
    Size = ModuleLayout->MR_ml_string_table_size;

#line 4229 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__StringTableChars_5  = (MR_Box) StringTableChars;
	 mdbcomp__rtti_access__Size_6  = Size;
#line 647 "rtti_access.m"
}
#line 638 "rtti_access.m"
    {
#line 638 "rtti_access.m"
      mdbcomp__rtti_access__StringTable_4 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), NULL, NULL);
#line 638 "rtti_access.m"
      MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__StringTable_4, 0) = ((MR_Box) (mdbcomp__rtti_access__StringTableChars_5));
#line 638 "rtti_access.m"
      MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__StringTable_4, 1) = ((MR_Box) (mdbcomp__rtti_access__Size_6));
#line 638 "rtti_access.m"
    }
#line 636 "rtti_access.m"
    return mdbcomp__rtti_access__StringTable_4;
#line 636 "rtti_access.m"
  }
#line 93 "rtti_access.m"
}

#line 90 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access__containing_module_layout_2_p_0(
#line 90 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__ProcLayout_1,
#line 90 "rtti_access.m"
  MR_Box * mdbcomp__rtti_access__ModuleLayout_2)
#line 90 "rtti_access.m"
{
#line 624 "rtti_access.m"
  {
#line 624 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 627 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__containing_module_layout_2_p_0

	const MR_ProcLayout * ProcLayout;
	const MR_ModuleLayout * ModuleLayout;
	MR_bool SUCCESS_INDICATOR;

	ProcLayout = (const MR_ProcLayout *) mdbcomp__rtti_access__ProcLayout_1 ;
		{
#line 627 "rtti_access.m"

    if (MR_PROC_LAYOUT_HAS_THIRD_GROUP(ProcLayout)) {
        ModuleLayout = ProcLayout->MR_sle_module_layout;
        SUCCESS_INDICATOR = MR_TRUE;
    } else {
        SUCCESS_INDICATOR = MR_FALSE;
    }

#line 4287 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	if (SUCCESS_INDICATOR) {
	 *mdbcomp__rtti_access__ModuleLayout_2  = (MR_Box) ModuleLayout;
#line 627 "rtti_access.m"
	}
mdbcomp__rtti_access__succeeded  = SUCCESS_INDICATOR;
}
#line 624 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 624 "rtti_access.m"
  }
#line 90 "rtti_access.m"
}

#line 73 "rtti_access.m"
MR_Box MR_CALL 
mdbcomp__rtti_access__proc_bytecode_bytes_1_f_0(
#line 73 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__ProcLayout_1)
#line 73 "rtti_access.m"
{
#line 573 "rtti_access.m"
  {
#line 573 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 573 "rtti_access.m"
    MR_Box mdbcomp__rtti_access__ByteCodeBytes_2;

#line 576 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__proc_bytecode_bytes_1_f_0

	const MR_ProcLayout * ProcLayout;
	const MR_uint_least8_t * ByteCodeBytes;

	ProcLayout = (const MR_ProcLayout *) mdbcomp__rtti_access__ProcLayout_1 ;
		{
#line 576 "rtti_access.m"

    ByteCodeBytes = ProcLayout->MR_sle_body_bytes;
#ifdef MR_DEBUG_PROC_REP
    printf("lookup_proc_bytecode: %p %p\n", ProcLayout, ByteCodeBytes);
#endif

#line 4334 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__ByteCodeBytes_2  = (MR_Box) ByteCodeBytes;
#line 576 "rtti_access.m"
}
#line 573 "rtti_access.m"
    return mdbcomp__rtti_access__ByteCodeBytes_2;
#line 573 "rtti_access.m"
  }
#line 73 "rtti_access.m"
}

#line 71 "rtti_access.m"
MR_Box MR_CALL 
mdbcomp__rtti_access__containing_proc_layout_1_f_0(
#line 71 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__LabelLayout_1)
#line 71 "rtti_access.m"
{
#line 566 "rtti_access.m"
  {
#line 566 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 566 "rtti_access.m"
    MR_Box mdbcomp__rtti_access__ProcLayout_2;

#line 569 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__containing_proc_layout_1_f_0

	const MR_LabelLayout * LabelLayout;
	const MR_ProcLayout * ProcLayout;

	LabelLayout = (const MR_LabelLayout *) mdbcomp__rtti_access__LabelLayout_1 ;
		{
#line 569 "rtti_access.m"

    ProcLayout = LabelLayout->MR_sll_entry;

#line 4375 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__ProcLayout_2  = (MR_Box) ProcLayout;
#line 569 "rtti_access.m"
}
#line 566 "rtti_access.m"
    return mdbcomp__rtti_access__ProcLayout_2;
#line 566 "rtti_access.m"
  }
#line 71 "rtti_access.m"
}

#line 69 "rtti_access.m"
MR_Word MR_CALL 
mdbcomp__rtti_access__get_all_modes_for_layout_1_f_0(
#line 69 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__Layout_1)
#line 69 "rtti_access.m"
{
#line 485 "rtti_access.m"
  {
#line 485 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 485 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Layouts_2;

#line 488 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__get_all_modes_for_layout_1_f_0

	const MR_ProcLayout * Layout;
	MR_Word Layouts;

	Layout = (const MR_ProcLayout *) mdbcomp__rtti_access__Layout_1 ;
		{
#line 488 "rtti_access.m"

    const MR_ModuleLayout   *module;
    const MR_ProcLayout     *proc;
    int                     i;
    MR_Word                 list;
    MR_bool                 match;
    const MR_ProcLayout     *selected_proc;

    selected_proc = Layout;

    if (! MR_PROC_LAYOUT_HAS_EXEC_TRACE(selected_proc)) {
        MR_fatal_error("get_all_modes_for_layout: selected_proc");
    }

    module = selected_proc->MR_sle_module_layout;
    list = MR_list_empty();
    for (i = 0; i < module->MR_ml_proc_count; i++) {
        proc = module->MR_ml_procs[i];
        if (! MR_PROC_LAYOUT_HAS_EXEC_TRACE(selected_proc)) {
            MR_fatal_error("get_all_modes_for_layout: proc");
        }

        if (MR_PROC_LAYOUT_IS_UCI(selected_proc)
            && MR_PROC_LAYOUT_IS_UCI(proc))
        {
            const MR_UCIProcId  *proc_id;
            const MR_UCIProcId  *selected_proc_id;

            proc_id = &proc->MR_sle_uci;
            selected_proc_id = &selected_proc->MR_sle_uci;

            if (MR_streq(proc_id->MR_uci_type_name,
                selected_proc_id->MR_uci_type_name)
            && MR_streq(proc_id->MR_uci_type_module,
                selected_proc_id->MR_uci_type_module)
            && MR_streq(proc_id->MR_uci_pred_name,
                selected_proc_id->MR_uci_pred_name)
            && (proc_id->MR_uci_type_arity ==
                selected_proc_id->MR_uci_type_arity))
            {
                match = MR_TRUE;
            } else {
                match = MR_FALSE;
            }
        } else if (!MR_PROC_LAYOUT_IS_UCI(selected_proc)
            && !MR_PROC_LAYOUT_IS_UCI(proc))
        {
            const MR_UserProcId *proc_id;
            const MR_UserProcId *selected_proc_id;

            proc_id = &proc->MR_sle_user;
            selected_proc_id = &selected_proc->MR_sle_user;

            if ((proc_id->MR_user_pred_or_func ==
                selected_proc_id->MR_user_pred_or_func)
            && MR_streq(proc_id->MR_user_decl_module,
                selected_proc_id->MR_user_decl_module)
            && MR_streq(proc_id->MR_user_name,
                selected_proc_id->MR_user_name)
            && (proc_id->MR_user_arity ==
                selected_proc_id->MR_user_arity))
            {
                match = MR_TRUE;
            } else {
                match = MR_FALSE;
            }
        } else {
            match = MR_FALSE;
        }

        if (match) {
            list = MR_int_list_cons((MR_Integer) proc, list);
        }
    }

    Layouts = list;

#line 4490 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__Layouts_2  = Layouts;
#line 488 "rtti_access.m"
}
#line 485 "rtti_access.m"
    return mdbcomp__rtti_access__Layouts_2;
#line 485 "rtti_access.m"
  }
#line 69 "rtti_access.m"
}

#line 66 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access__find_initial_version_arg_num_3_p_0(
#line 66 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__Layout_1,
#line 66 "rtti_access.m"
  MR_Integer mdbcomp__rtti_access__OutArgNum_2,
#line 66 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__InArgNum_3)
#line 66 "rtti_access.m"
{
#line 344 "rtti_access.m"
  {
#line 344 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 347 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__find_initial_version_arg_num_3_p_0

	const MR_ProcLayout * Layout;
	MR_Integer OutArgNum;
	MR_Integer InArgNum;
	MR_bool SUCCESS_INDICATOR;

	Layout = (const MR_ProcLayout *) mdbcomp__rtti_access__Layout_1 ;
	OutArgNum =  mdbcomp__rtti_access__OutArgNum_2 ;
		{
#line 347 "rtti_access.m"

    const MR_ProcLayout     *proc;
    int                     out_hlds_num;
    const char              *out_name;
    int                     should_copy_out;

    proc = Layout;

    if (! MR_PROC_LAYOUT_HAS_EXEC_TRACE(proc)) {
        MR_fatal_error("find_initial_version_arg_num: proc");
    }

    out_hlds_num = proc->MR_sle_head_var_nums[OutArgNum - 1];
    out_name = MR_hlds_var_name(proc, out_hlds_num, &should_copy_out);
    if (out_name == NULL || MR_streq(out_name, "")) {
        /* out_hlds_num was not named by the user */
        SUCCESS_INDICATOR = MR_FALSE;
    } else {
        char                    out_name_buf[MR_MAX_VARNAME_SIZE];
        int                     out_base_name_len;
        int                     out_numerical_suffix;
        int                     num_matches;
        int                     in_hlds_num;
        int                     in_arg_num;
        const char              *in_name;
        int                     start_of_num;
        int                     in_numerical_suffix;
        int                     head_var_num;
        int                     call_var_num;
        int                     call_num_vars;
        const MR_LabelLayout    *call_label;
        MR_bool                 found;

        if (should_copy_out) {
            strncpy(out_name_buf, out_name, MR_MAX_VARNAME_SIZE);
            out_name = (const char *) out_name_buf;
        }

        start_of_num = MR_find_start_of_num_suffix(out_name);
        if (start_of_num < 0) {
            out_base_name_len = strlen(out_name);
            out_numerical_suffix = -1;
        } else {
            out_base_name_len = start_of_num;
            out_numerical_suffix = atoi(out_name + start_of_num);
        }

        num_matches = 0;
        in_arg_num = -1;

        for (head_var_num = 0; head_var_num < proc->MR_sle_num_head_vars;
            head_var_num++)
        {
            in_hlds_num = proc->MR_sle_head_var_nums[head_var_num];
            in_name = MR_hlds_var_name(proc, in_hlds_num, NULL);
            if (in_name == NULL || MR_streq(in_name, "")) {
                continue;
            }

            start_of_num = MR_find_start_of_num_suffix(in_name);
            if (start_of_num < 0) {
                continue;
            }

            if (! (
                    (
                        /*
                        ** The names are exactly the same except
                        ** for the numerical suffix.
                        */
                        start_of_num == out_base_name_len &&
                        MR_strneq(out_name, in_name, start_of_num)
                    )
                ||
                    (
                        /*
                        ** The names are exactly the same except
                        ** for an underscore and the numerical suffix
                        ** (as is the case with state variable notation).
                        */
                        start_of_num == out_base_name_len + 1 &&
                        start_of_num > 0 &&
                        in_name[start_of_num - 1] == '_' &&
                        MR_strneq(out_name, in_name, start_of_num - 1)
                    )
                ))
            {
                continue;
            }

            in_numerical_suffix = atoi(in_name + start_of_num);
            if (! ((in_numerical_suffix >= out_numerical_suffix)
                || (out_numerical_suffix < 0)))
            {
                continue;
            }

            call_label = proc->MR_sle_call_label;
            if (! MR_has_valid_var_count(call_label)) {
                    continue;
            }

            if (! MR_has_valid_var_info(call_label)) {
                continue;
            }

            /*
            ** The in_hlds_num has the same prefix as the output variable.
            ** Check if in_hlds_num is an input argument.
            */
            call_num_vars = MR_all_desc_var_count(call_label);
            found = MR_FALSE;
            for (call_var_num = 0 ; call_var_num < call_num_vars;
                    call_var_num++)
            {
                if (call_label->MR_sll_var_nums[call_var_num] == in_hlds_num) {
                    found = MR_TRUE;
                    break;
                }
            }

            if (! found) {
                continue;
            }

            num_matches++;
            in_arg_num = head_var_num;
        }

        if (num_matches == 1) {
            InArgNum = in_arg_num + 1;
            SUCCESS_INDICATOR = MR_TRUE;
        } else {
            SUCCESS_INDICATOR = MR_FALSE;
        }
    }

#line 4670 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	if (SUCCESS_INDICATOR) {
	 *mdbcomp__rtti_access__InArgNum_3  = InArgNum;
#line 347 "rtti_access.m"
	}
mdbcomp__rtti_access__succeeded  = SUCCESS_INDICATOR;
}
#line 344 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 344 "rtti_access.m"
  }
#line 66 "rtti_access.m"
}

#line 48 "rtti_access.m"
MR_String MR_CALL 
mdbcomp__rtti_access__get_proc_name_1_f_0(
#line 48 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__HeadVar__1_1)
#line 48 "rtti_access.m"
{
#line 285 "rtti_access.m"
  {
#line 285 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 285 "rtti_access.m"
    MR_String mdbcomp__rtti_access__ProcName_2;

#line 285 "rtti_access.m"
    if (((MR_tag((MR_Word) mdbcomp__rtti_access__HeadVar__1_1)) == (MR_mktag((MR_Integer) 0))))
#line 285 "rtti_access.m"
      {
#line 285 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 0)));
#line 285 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 1)));
#line 285 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 2)));
#line 285 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_7_7;
#line 285 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_8_8;

#line 285 "rtti_access.m"
        mdbcomp__rtti_access__ProcName_2 = ((MR_String) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 3)));
#line 285 "rtti_access.m"
        mdbcomp__rtti_access__V_7_7 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 4)));
#line 285 "rtti_access.m"
        mdbcomp__rtti_access__V_8_8 = ((MR_Integer) (MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 5)));
#line 285 "rtti_access.m"
      }
#line 285 "rtti_access.m"
    else
#line 286 "rtti_access.m"
      {
#line 286 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 0)));
#line 286 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 1)));
#line 286 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 2)));
#line 286 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_13_13;
#line 286 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_14_14;

#line 286 "rtti_access.m"
        mdbcomp__rtti_access__ProcName_2 = ((MR_String) (MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 3)));
#line 286 "rtti_access.m"
        mdbcomp__rtti_access__V_13_13 = ((MR_Integer) (MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 4)));
#line 286 "rtti_access.m"
        mdbcomp__rtti_access__V_14_14 = ((MR_Integer) (MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 5)));
#line 286 "rtti_access.m"
      }
#line 285 "rtti_access.m"
    return mdbcomp__rtti_access__ProcName_2;
#line 285 "rtti_access.m"
  }
#line 48 "rtti_access.m"
}

#line 46 "rtti_access.m"
MR_Word MR_CALL 
mdbcomp__rtti_access__get_proc_label_from_layout_1_f_0(
#line 46 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__Layout_3)
#line 46 "rtti_access.m"
{
#line 276 "rtti_access.m"
  {
#line 276 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 276 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__ProcLabel_4;

#line 293 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__get_proc_label_from_layout_1_f_0

	const MR_ProcLayout * Layout;
	MR_bool SUCCESS_INDICATOR;

	Layout = (const MR_ProcLayout *) mdbcomp__rtti_access__Layout_3 ;
		{
#line 293 "rtti_access.m"

    if (MR_PROC_ID_IS_UCI(Layout->MR_sle_proc_id)) {
        SUCCESS_INDICATOR = MR_TRUE;
    } else {
        SUCCESS_INDICATOR = MR_FALSE;
    }

#line 4785 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	if (SUCCESS_INDICATOR) {
#line 293 "rtti_access.m"
	}
mdbcomp__rtti_access__succeeded  = SUCCESS_INDICATOR;
}
#line 276 "rtti_access.m"
    if (mdbcomp__rtti_access__succeeded)
#line 266 "rtti_access.m"
      {
#line 266 "rtti_access.m"
        MR_String mdbcomp__rtti_access__TypeName_5;
#line 266 "rtti_access.m"
        MR_String mdbcomp__rtti_access__TypeModule_6;
#line 266 "rtti_access.m"
        MR_String mdbcomp__rtti_access__DefModule_7;
#line 266 "rtti_access.m"
        MR_String mdbcomp__rtti_access__PredName_8;
#line 266 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__TypeArity_9;
#line 266 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__ModeNum_10;
#line 266 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__SpecialId_14;
#line 266 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__SymDefModule_15;
#line 266 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__SymTypeModule_16;
#line 269 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__SpecialIdPrime_11;
#line 267 "rtti_access.m"
        MR_String mdbcomp__rtti_access__V_12_12;
#line 267 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__V_13_13;

#line 308 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__get_proc_label_from_layout_1_f_0

	const MR_ProcLayout * Layout;
	MR_String TypeName;
	MR_String TypeModule;
	MR_String DefModule;
	MR_String PredName;
	MR_Integer TypeArity;
	MR_Integer ModeNum;

	Layout = (const MR_ProcLayout *) mdbcomp__rtti_access__Layout_3 ;
		{
#line 308 "rtti_access.m"

    const MR_UCIProcId  *proc_id;

    proc_id = &Layout->MR_sle_uci;

    /* The casts are there to cast away const without warnings */
    TypeName   = (MR_String) (MR_Integer) proc_id->MR_uci_type_name;
    TypeModule = (MR_String) (MR_Integer) proc_id->MR_uci_type_module;
    DefModule  = (MR_String) (MR_Integer) proc_id->MR_uci_def_module;
    PredName   = (MR_String) (MR_Integer) proc_id->MR_uci_pred_name;
    TypeArity  = proc_id->MR_uci_type_arity;
    ModeNum    = proc_id->MR_uci_mode;

#line 4851 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__TypeName_5  = TypeName;
	 mdbcomp__rtti_access__TypeModule_6  = TypeModule;
	 mdbcomp__rtti_access__DefModule_7  = DefModule;
	 mdbcomp__rtti_access__PredName_8  = PredName;
	 mdbcomp__rtti_access__TypeArity_9  = TypeArity;
	 mdbcomp__rtti_access__ModeNum_10  = ModeNum;
#line 308 "rtti_access.m"
}
#line 267 "rtti_access.m"
        {
#line 267 "rtti_access.m"
          mdbcomp__rtti_access__succeeded = mdbcomp__prim_data__special_pred_name_arity_4_p_2(&mdbcomp__rtti_access__SpecialIdPrime_11, &mdbcomp__rtti_access__V_12_12, mdbcomp__rtti_access__PredName_8, &mdbcomp__rtti_access__V_13_13);
        }
#line 269 "rtti_access.m"
        if (mdbcomp__rtti_access__succeeded)
#line 268 "rtti_access.m"
          mdbcomp__rtti_access__SpecialId_14 = mdbcomp__rtti_access__SpecialIdPrime_11;
#line 269 "rtti_access.m"
        else
#line 270 "rtti_access.m"
          {
#line 270 "rtti_access.m"
            {
#line 270 "rtti_access.m"
              mercury__require__unexpected_3_p_0((MR_String) "mdbcomp.rtti_access", (MR_String) "function \140mdbcomp.rtti_access.get_proc_label_from_layout\'/1", (MR_String) "bad special_pred_id");
            }
#line 270 "rtti_access.m"
          }
#line 272 "rtti_access.m"
        {
#line 272 "rtti_access.m"
          mdbcomp__rtti_access__SymDefModule_15 = mdbcomp__prim_data__string_to_sym_name_1_f_0(mdbcomp__rtti_access__DefModule_7);
        }
#line 273 "rtti_access.m"
        {
#line 273 "rtti_access.m"
          mdbcomp__rtti_access__SymTypeModule_16 = mdbcomp__prim_data__string_to_sym_name_1_f_0(mdbcomp__rtti_access__TypeModule_6);
        }
#line 274 "rtti_access.m"
        {
#line 274 "rtti_access.m"
          mdbcomp__rtti_access__ProcLabel_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 6 * sizeof(MR_Word)), NULL, NULL));
#line 274 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__ProcLabel_4, 0) = ((MR_Box) (mdbcomp__rtti_access__SymDefModule_15));
#line 274 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__ProcLabel_4, 1) = ((MR_Box) (mdbcomp__rtti_access__SpecialId_14));
#line 274 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__ProcLabel_4, 2) = ((MR_Box) (mdbcomp__rtti_access__SymTypeModule_16));
#line 274 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__ProcLabel_4, 3) = ((MR_Box) (mdbcomp__rtti_access__TypeName_5));
#line 274 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__ProcLabel_4, 4) = ((MR_Box) (mdbcomp__rtti_access__TypeArity_9));
#line 274 "rtti_access.m"
          MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__ProcLabel_4, 5) = ((MR_Box) (mdbcomp__rtti_access__ModeNum_10));
#line 274 "rtti_access.m"
        }
#line 266 "rtti_access.m"
      }
#line 276 "rtti_access.m"
    else
#line 278 "rtti_access.m"
      {
#line 278 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__PredOrFunc_17;
#line 278 "rtti_access.m"
        MR_String mdbcomp__rtti_access__DeclModule_18;
#line 278 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__Arity_19;
#line 278 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__SymDeclModule_20;
#line 278 "rtti_access.m"
        MR_String mdbcomp__rtti_access__DefModule_24;
#line 278 "rtti_access.m"
        MR_String mdbcomp__rtti_access__PredName_25;
#line 278 "rtti_access.m"
        MR_Integer mdbcomp__rtti_access__ModeNum_26;
#line 278 "rtti_access.m"
        MR_Word mdbcomp__rtti_access__SymDefModule_27;

#line 330 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__get_proc_label_from_layout_1_f_0

	const MR_ProcLayout * Layout;
	MR_Word PredOrFunc;
	MR_String DeclModule;
	MR_String DefModule;
	MR_String PredName;
	MR_Integer Arity;
	MR_Integer ModeNum;

	Layout = (const MR_ProcLayout *) mdbcomp__rtti_access__Layout_3 ;
		{
#line 330 "rtti_access.m"

    const MR_UserProcId *proc_id;

    proc_id = &Layout->MR_sle_user;

    /* The casts are there to cast away const without warnings */
    PredOrFunc = proc_id->MR_user_pred_or_func;
    DeclModule = (MR_String) (MR_Integer) proc_id->MR_user_decl_module;
    DefModule  = (MR_String) (MR_Integer) proc_id->MR_user_def_module;
    PredName   = (MR_String) (MR_Integer) proc_id->MR_user_name;
    Arity      = proc_id->MR_user_arity;
    ModeNum    = proc_id->MR_user_mode;

#line 4962 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__PredOrFunc_17  = PredOrFunc;
	 mdbcomp__rtti_access__DeclModule_18  = DeclModule;
	 mdbcomp__rtti_access__DefModule_24  = DefModule;
	 mdbcomp__rtti_access__PredName_25  = PredName;
	 mdbcomp__rtti_access__Arity_19  = Arity;
	 mdbcomp__rtti_access__ModeNum_26  = ModeNum;
#line 330 "rtti_access.m"
}
#line 279 "rtti_access.m"
        {
#line 279 "rtti_access.m"
          mdbcomp__rtti_access__SymDefModule_27 = mdbcomp__prim_data__string_to_sym_name_1_f_0(mdbcomp__rtti_access__DefModule_24);
        }
#line 280 "rtti_access.m"
        {
#line 280 "rtti_access.m"
          mdbcomp__rtti_access__SymDeclModule_20 = mdbcomp__prim_data__string_to_sym_name_1_f_0(mdbcomp__rtti_access__DeclModule_18);
        }
#line 281 "rtti_access.m"
        {
#line 281 "rtti_access.m"
          mdbcomp__rtti_access__ProcLabel_4 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 6 * sizeof(MR_Word)), NULL, NULL);
#line 281 "rtti_access.m"
          MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ProcLabel_4, 0) = ((MR_Box) (mdbcomp__rtti_access__SymDefModule_27));
#line 281 "rtti_access.m"
          MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ProcLabel_4, 1) = ((MR_Box) (mdbcomp__rtti_access__PredOrFunc_17));
#line 281 "rtti_access.m"
          MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ProcLabel_4, 2) = ((MR_Box) (mdbcomp__rtti_access__SymDeclModule_20));
#line 281 "rtti_access.m"
          MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ProcLabel_4, 3) = ((MR_Box) (mdbcomp__rtti_access__PredName_25));
#line 281 "rtti_access.m"
          MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ProcLabel_4, 4) = ((MR_Box) (mdbcomp__rtti_access__Arity_19));
#line 281 "rtti_access.m"
          MR_hl_field(MR_mktag(0), mdbcomp__rtti_access__ProcLabel_4, 5) = ((MR_Box) (mdbcomp__rtti_access__ModeNum_26));
#line 281 "rtti_access.m"
        }
#line 278 "rtti_access.m"
      }
#line 276 "rtti_access.m"
    return mdbcomp__rtti_access__ProcLabel_4;
#line 276 "rtti_access.m"
  }
#line 46 "rtti_access.m"
}

#line 39 "rtti_access.m"
MR_bool MR_CALL 
mdbcomp__rtti_access__get_context_from_label_layout_3_p_0(
#line 39 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__Label_1,
#line 39 "rtti_access.m"
  MR_String * mdbcomp__rtti_access__FileName_2,
#line 39 "rtti_access.m"
  MR_Integer * mdbcomp__rtti_access__LineNo_3)
#line 39 "rtti_access.m"
{
#line 227 "rtti_access.m"
  {
#line 227 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;

#line 230 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__get_context_from_label_layout_3_p_0

	const MR_LabelLayout * Label;
	MR_String FileName;
	MR_Integer LineNo;
	MR_bool SUCCESS_INDICATOR;

	Label = (const MR_LabelLayout *) mdbcomp__rtti_access__Label_1 ;
		{
#line 230 "rtti_access.m"

    const char  *filename;
    int         line_no;

    SUCCESS_INDICATOR = MR_find_context(Label, &filename, &line_no);
    LineNo = (MR_Integer) line_no;
    MR_TRACE_USE_HP(
        MR_make_aligned_string(FileName, (MR_String) filename);
    );

#line 5049 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	if (SUCCESS_INDICATOR) {
	 *mdbcomp__rtti_access__FileName_2  = FileName;
	 *mdbcomp__rtti_access__LineNo_3  = LineNo;
#line 230 "rtti_access.m"
	}
mdbcomp__rtti_access__succeeded  = SUCCESS_INDICATOR;
}
#line 227 "rtti_access.m"
    return mdbcomp__rtti_access__succeeded;
#line 227 "rtti_access.m"
  }
#line 39 "rtti_access.m"
}

#line 37 "rtti_access.m"
MR_Word MR_CALL 
mdbcomp__rtti_access__get_path_port_from_label_layout_1_f_0(
#line 37 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__Label_3)
#line 37 "rtti_access.m"
{
#line 248 "rtti_access.m"
  {
#line 248 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 248 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__PathPort_4;
#line 248 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Port_5;
#line 248 "rtti_access.m"
    MR_String mdbcomp__rtti_access__GoalPathStr_6;
#line 248 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__GoalPath_7;

#line 244 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__get_path_port_from_label_layout_1_f_0

	const MR_LabelLayout * Label;
	MR_Word Port;

	Label = (const MR_LabelLayout *) mdbcomp__rtti_access__Label_3 ;
		{
#line 244 "rtti_access.m"

    Port = Label->MR_sll_port;

#line 5100 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__Port_5  = Port;
#line 244 "rtti_access.m"
}
#line 219 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__get_path_port_from_label_layout_1_f_0

	const MR_LabelLayout * Label;
	MR_String GoalPath;

	Label = (const MR_LabelLayout *) mdbcomp__rtti_access__Label_3 ;
		{
#line 219 "rtti_access.m"

    GoalPath = (MR_String) MR_label_goal_path(Label);

#line 5120 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__GoalPathStr_6  = GoalPath;
#line 219 "rtti_access.m"
}
#line 251 "rtti_access.m"
    {
#line 251 "rtti_access.m"
      mdbcomp__goal_path__rev_goal_path_from_string_det_2_p_0(mdbcomp__rtti_access__GoalPathStr_6, &mdbcomp__rtti_access__GoalPath_7);
    }
#line 252 "rtti_access.m"
    {
#line 252 "rtti_access.m"
      return mdbcomp__rtti_access__PathPort_4 = mdbcomp__trace_counts__make_path_port_2_f_0(mdbcomp__rtti_access__GoalPath_7, mdbcomp__rtti_access__Port_5);
    }
#line 248 "rtti_access.m"
    return mdbcomp__rtti_access__PathPort_4;
#line 248 "rtti_access.m"
  }
#line 37 "rtti_access.m"
}

#line 35 "rtti_access.m"
MR_Word MR_CALL 
mdbcomp__rtti_access__get_port_from_label_layout_1_f_0(
#line 35 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__Label_1)
#line 35 "rtti_access.m"
{
#line 241 "rtti_access.m"
  {
#line 241 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 241 "rtti_access.m"
    MR_Word mdbcomp__rtti_access__Port_2;

#line 244 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__get_port_from_label_layout_1_f_0

	const MR_LabelLayout * Label;
	MR_Word Port;

	Label = (const MR_LabelLayout *) mdbcomp__rtti_access__Label_1 ;
		{
#line 244 "rtti_access.m"

    Port = Label->MR_sll_port;

#line 5171 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__Port_2  = Port;
#line 244 "rtti_access.m"
}
#line 241 "rtti_access.m"
    return mdbcomp__rtti_access__Port_2;
#line 241 "rtti_access.m"
  }
#line 35 "rtti_access.m"
}

#line 33 "rtti_access.m"
MR_String MR_CALL 
mdbcomp__rtti_access__get_goal_path_from_maybe_label_1_f_0(
#line 33 "rtti_access.m"
  MR_Word mdbcomp__rtti_access__HeadVar__1_1)
#line 33 "rtti_access.m"
{
#line 224 "rtti_access.m"
  {
#line 224 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 224 "rtti_access.m"
    MR_String mdbcomp__rtti_access__HeadVar__2_2;

#line 224 "rtti_access.m"
    if ((mdbcomp__rtti_access__HeadVar__1_1 == ((MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)))))
#line 225 "rtti_access.m"
      mdbcomp__rtti_access__HeadVar__2_2 = (MR_String) "";
#line 224 "rtti_access.m"
    else
#line 224 "rtti_access.m"
      {
#line 224 "rtti_access.m"
        MR_Box mdbcomp__rtti_access__Label_3 = ((MR_Box) (MR_hl_field(MR_mktag(1), mdbcomp__rtti_access__HeadVar__1_1, (MR_Integer) 0)));

#line 219 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__get_goal_path_from_maybe_label_1_f_0

	const MR_LabelLayout * Label;
	MR_String GoalPath;

	Label = (const MR_LabelLayout *) mdbcomp__rtti_access__Label_3 ;
		{
#line 219 "rtti_access.m"

    GoalPath = (MR_String) MR_label_goal_path(Label);

#line 5223 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__HeadVar__2_2  = GoalPath;
#line 219 "rtti_access.m"
}
#line 224 "rtti_access.m"
      }
#line 224 "rtti_access.m"
    return mdbcomp__rtti_access__HeadVar__2_2;
#line 224 "rtti_access.m"
  }
#line 33 "rtti_access.m"
}

#line 31 "rtti_access.m"
MR_String MR_CALL 
mdbcomp__rtti_access__get_goal_path_from_label_layout_1_f_0(
#line 31 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__Label_1)
#line 31 "rtti_access.m"
{
#line 216 "rtti_access.m"
  {
#line 216 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 216 "rtti_access.m"
    MR_String mdbcomp__rtti_access__GoalPath_2;

#line 219 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__get_goal_path_from_label_layout_1_f_0

	const MR_LabelLayout * Label;
	MR_String GoalPath;

	Label = (const MR_LabelLayout *) mdbcomp__rtti_access__Label_1 ;
		{
#line 219 "rtti_access.m"

    GoalPath = (MR_String) MR_label_goal_path(Label);

#line 5266 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__GoalPath_2  = GoalPath;
#line 219 "rtti_access.m"
}
#line 216 "rtti_access.m"
    return mdbcomp__rtti_access__GoalPath_2;
#line 216 "rtti_access.m"
  }
#line 31 "rtti_access.m"
}

#line 29 "rtti_access.m"
MR_Box MR_CALL 
mdbcomp__rtti_access__get_proc_layout_from_label_layout_1_f_0(
#line 29 "rtti_access.m"
  MR_Box mdbcomp__rtti_access__Label_1)
#line 29 "rtti_access.m"
{
#line 209 "rtti_access.m"
  {
#line 209 "rtti_access.m"
    MR_bool mdbcomp__rtti_access__succeeded;
#line 209 "rtti_access.m"
    MR_Box mdbcomp__rtti_access__ProcLayout_2;

#line 212 "rtti_access.m"
{
#define MR_PROC_LABEL mdbcomp__rtti_access__get_proc_layout_from_label_layout_1_f_0

	const MR_LabelLayout * Label;
	const MR_ProcLayout * ProcLayout;

	Label = (const MR_LabelLayout *) mdbcomp__rtti_access__Label_1 ;
		{
#line 212 "rtti_access.m"

    ProcLayout = Label->MR_sll_entry;

#line 5307 "mdbcomp.rtti_access.c"

		;}
#undef MR_PROC_LABEL
	 mdbcomp__rtti_access__ProcLayout_2  = (MR_Box) ProcLayout;
#line 212 "rtti_access.m"
}
#line 209 "rtti_access.m"
    return mdbcomp__rtti_access__ProcLayout_2;
#line 209 "rtti_access.m"
  }
#line 29 "rtti_access.m"
}

void mercury__mdbcomp__rtti_access__init(void)
{
}

void mercury__mdbcomp__rtti_access__init_type_tables(void)
{
	static MR_bool initialised = MR_FALSE;
	if (initialised) return;
	initialised = MR_TRUE;

	MR_register_type_ctor_info(&mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_bytecode_0);
	MR_register_type_ctor_info(&mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_bytecode_bytes_0);
	MR_register_type_ctor_info(&mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_label_layout_0);
	MR_register_type_ctor_info(&mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_module_layout_0);
	MR_register_type_ctor_info(&mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_proc_layout_0);
	MR_register_type_ctor_info(&mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_string_table_0);
	MR_register_type_ctor_info(&mdbcomp__rtti_access__mdbcomp__rtti_access__type_ctor_info_string_table_chars_0);
}

void mercury__mdbcomp__rtti_access__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module mdbcomp.rtti_access. */
