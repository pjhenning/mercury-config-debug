%-----------------------------------------------------------------------------%
% Copyright (C) 2003, 2005 The University of Melbourne.
% This file may only be copied under the terms of the GNU General
% Public License - see the file COPYING in the Mercury distribution.
%-----------------------------------------------------------------------------%
% File: mer_mdbcomp.m
%
% This file is only present so that the mdbcomp library is
% generated with the correct name.
%-----------------------------------------------------------------------------%

:- module mer_mdbcomp.

:- implementation.

:- import_module mdbcomp.
